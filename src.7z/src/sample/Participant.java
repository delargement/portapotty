package sample;// Q1: Write the complete class declaration for this class.
// Include all necessary instance variables and implementations of its constructor and method(s),
// except for those that have been provided for through inheritance.

// You should have at least 1 pair of accessor and mutator.
// Note that a deep copy of objects should be created for attributes of reference type.
public class Participant extends User {
    private String contactNumber, nameOfOrganisation;
    private Event event;
    public Participant(String name, String contactNumber, String nameOfOrganisation, Event event){
        super(name);
        this.contactNumber=contactNumber;
        this.nameOfOrganisation=nameOfOrganisation;
        this.event=new Event(event.getEventID(),event.getEventCost());
    }
    public Participant(String name, Event event){
        this(name,"unknown","unknown",event);
    }

    @Override
    public String toString() {
        return "Participant [" + super.toString() +
                "contactNumber=" + contactNumber +
                ", nameOfOrganisation=" + nameOfOrganisation +
                ", event=" + event +
                ']';
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getNameOfOrganisation() {
        return nameOfOrganisation;
    }

    public void setNameOfOrganisation(String nameOfOrganisation) {
        this.nameOfOrganisation = nameOfOrganisation;
    }

    public Event getEvent() {
        return event;
    }

    public void setEvent(Event event) {
        this.event = event;
    }
}
