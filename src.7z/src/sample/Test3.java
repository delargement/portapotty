package sample;

public class Test3 {
	
	public static void main(String[] args) throws Exception {
		ScreenController screen = new ScreenController();
		ParticipantDatabase db = new ParticipantDatabase();
		LoadList.readRegistrationData(db);

		System.out.println("Sort by eventID, Organisation and then by name");
//		Un-comment after you have created Participant.java
//	    Collections.sort(db.getDatabase(), new SortRegistration());
	    db.displayAllParticipants(screen);
	}
}
