package sample;

import java.util.ArrayList;


public class Test2 {
    public static void main(String[] args) {
        ScreenController screen = new ScreenController();
        ParticipantDatabase db = new ParticipantDatabase();

        ArrayList<Event> env = new ArrayList<Event>(3);
        env.add(new Event("CS3233",500.80));
        env.add(new Event("CS3201",200.90));

        db.addParticipant(new Participant("John", env.get(0)));
        db.addParticipant(new Participant("Peter","91212123", "NUS High School",env.get(1)));

        db.displayAllParticipants(screen);

        ArrayList<Participant> pList =  db.getParticipants("CS3201");//get information by event ID

        System.out.println("sign up size:"+pList.size());
        db.displayAllParticipants(pList, screen); //print out list who have signed up for CS3201

        /**Mary paid but is not registered in database
         * Method checkStatus() will return "true" if participant is captured in
         * ParticipantDatabse and has paid for the event. Else return false.
         */
        Participant p2 = new Participant("Mary","92323231", "NUS Junior School",env.get(1));
        p2.setHasPaid(true);
        System.out.println("is participant and hasPaid?"+db.checkStatus(p2));//should show false

    }

}
