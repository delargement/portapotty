package sample;

import java.util.Comparator;

public class SortRegistration implements Comparator<Participant>{
    public int compare(Participant o1, Participant o2){
        if (o1.getEvent().getEventID().compareTo(o2.getEvent().getEventID()) == 0){
            if(o1.getNameOfOrganisation().compareTo(o2.getNameOfOrganisation()) == 0){
                return o1.getName().compareTo(o2.getName());
            } else
                return o1.getNameOfOrganisation().compareTo(o2.getNameOfOrganisation());
        } else{
            return o1.getEvent().getEventID().compareTo(o2.getEvent().getEventID());
        }
    }

}
