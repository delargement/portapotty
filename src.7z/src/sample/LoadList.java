package sample;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class LoadList {
	
	public static void readRegistrationData(ParticipantDatabase db)throws FileNotFoundException{
		Scanner sc =
		        new Scanner(new FileReader("sample/registration_list.csv"));
		Scanner wordScan=null;
		Participant p=null;

		  	while (sc.hasNextLine()){
		  		
		  		wordScan= new Scanner(sc.nextLine());
		  		wordScan.useDelimiter(",");
		  		while (wordScan.hasNext()) {
		  			String name = wordScan.next();
		  			String organisation = wordScan.next();
		  			String contactNumber = wordScan.next();
		  			String event = wordScan.next();
		  			double eventCost = Double.parseDouble(wordScan.next());
		  			String paid = wordScan.next();
		  			p = new Participant(name,contactNumber, organisation,
	  								new Event(event,eventCost));
		  			if(paid.equals("Y")) {
		  				p.setHasPaid(true);
		  			}
		  			else
		  				p.setHasPaid(false);
		  			
				}
		  		db.addParticipant(p);
//				System.out.println(p);
		  	}
		  	// Close the file once all data has been read.
		

		 sc.close();
		 
		 wordScan.close();
	}
	
	

}
