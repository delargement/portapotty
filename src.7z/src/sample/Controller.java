package sample;

import java.io.FileNotFoundException;
import java.util.Collections;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

// Complete Q5a, 5b, 5c here. (Read the question)
public class Controller {

	ParticipantDatabase db = new ParticipantDatabase();

	int numTransLeft;

	@FXML
	private TextArea transactionTextArea;

	@FXML
	private TextArea processedTextArea;

	@FXML
	private TextField passwordField;

	@FXML
	private Button start;

	@FXML
	private Label statusBar;

	@FXML
	private Label firstTransLabel;

	@FXML
	private Label displayFirstTransLabel;

	@FXML
	private Label displayNumTransLabel;

	@FXML
	private ToggleGroup group;

	public Controller(){


		try {

			LoadList.readRegistrationData(db);

		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}
	/**
	 * event handler for mouse event
	 * Q5a
	 */
	public void handleClickTrans(ActionEvent actionEvent){
		displayTransaction();
	}

	@FXML
	public void displayTransaction(){
		//add relevant codes
        ParticipantDatabase p = new ParticipantDatabase();
       	p.readParticipants();
       	String s="";
       	for(var v: ParticipantDatabase.getDatabase()){
       		s+=v;
		}
       	processedTextArea.setText(s);
	}

	/**
	 * Q5b

	 */
	//create checkPassword() method here.
    public boolean checkPassword(String s){
		return s.matches(".*\\d.*") && s.matches(".*[a-z].*") && s.matches(".{4,9}[#%$]");
	}

	/**
	 * Q5c:
	 */
	public void	handleProcess(ActionEvent actionEvent){
		if (!checkPassword(passwordField.getText()))
			return;
		var db = ParticipantDatabase.getDatabase();
		for(var v: db){
			v.setHasPaid(true);
		}
		Collections.sort(db, new SortRegistration());
		firstTransLabel.setText("Registration ID:" + db.get(0).getAccountID());
		startTask();
	}
	@FXML
	public void processRegistration() 
	{
		//add codes

		var db = ParticipantDatabase.getDatabase();
		for(int i = 0; i < db.size(); ++i){
			statusBar.setText("Processing " + db.get(i).getName());
			displayNumTransLabel.setText(db.size()-i+"");
			db.get(i).setHasPaid(true);
			transactionTextArea.appendText(db.get(i).toString());
		}
	}

	@FXML
	public void startTask() 
	{
		// Create a Runnable
		Runnable task = new Runnable()
		{
			public void run()
			{
				processRegistration();
			}
		};

		// Run the task in a background thread
		Thread backgroundThread = new Thread(task);
		// Terminate the running thread if the application exits
		backgroundThread.setDaemon(true);
		// Start the thread
		backgroundThread.start();

	}

}
