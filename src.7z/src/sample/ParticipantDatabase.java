package sample;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

// Q3: Add relevant code in ParticipantDatabase.java so that you could obtain the output in Appendix 3-1.

// Q4: Create a NEW CLASS called SortRegistration and implement the Comparator interface.
// Sort the event's list by the eventID, followed by organisation name, and finally by participant's name
public class ParticipantDatabase {
    private final static File FILE = new File("registration_list.csv");

	private static ArrayList<Participant> db;
	
	public ParticipantDatabase() {
		db = new ArrayList<>();
	}
	
	public static void addParticipant(Participant p) {
		db.add(p);
	}
	
	public void displayAllParticipants(ScreenController s) {
		db.forEach(participant->s.displayMessage(participant));
	}
	
	public void displayAllParticipants(ArrayList<Participant> list, ScreenController s) {
		list.forEach(participant->s.displayMessage(participant));
	}
	public ArrayList<Participant> getParticipants(String s){
		readParticipants();
		var plist = new ArrayList<Participant>();
		for(var v: db){
			if (v.getEvent().getEventID().equals(s)){
				plist.add(v);
			}
		}
		return plist;
	}
	public void readParticipants(){
		try {
			LoadList.readRegistrationData(this);
//			Scanner inp = new Scanner(FILE);
//			while(inp.hasNext()){
//				String line = inp.nextLine();
//				String[] tok = line.split("[,]");
//				Participant p = new Participant(tok[0],tok[2],tok[1],new Event(tok[3],Double.parseDouble(tok[4])));
//				p.setHasPaid(tok[5].equals("Y"));
//				addParticipant(p);
//			}
		}catch(FileNotFoundException ex){
		    ex.printStackTrace();
		}
	}

	public boolean checkStatus(Participant p){
		return isParticipant(p) && p.hasPaid();
	}
	
	public boolean isParticipant(Participant p) {
		return db.contains(p);
	}
	
	public int getSize() {
		return db.size();
		
	}
	public static ArrayList<Participant> getDatabase() {
		return db;
	}
	
	
	
}
