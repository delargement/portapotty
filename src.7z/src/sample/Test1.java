package sample;

import java.util.ArrayList;

public class Test1 {

	public static void main(String[] args) {
		ScreenController screenController = new ScreenController();
		
		ArrayList<Event> env = new ArrayList<Event>(3);
		env.add(new Event("CS3233",500.80));
		env.add(new Event("CS3201",200.90));
		
		//name + event
		Participant p1 = new Participant("John", env.get(0));
		
		//name + handphone+ Organisation+ event
		Participant p2 = new Participant("Peter","91212123", "NUS High School",env.get(1));
		p1.setHasPaid(true);
		screenController.displayMessage(p1);
		screenController.displayMessage(p2);

	}

}
