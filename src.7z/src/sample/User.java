package sample;

public class User {
	private String name;
	private String accountID;
	private boolean hasPaid;//keep track of whether paid or not
	private static int idGenerator=0;


	public User(String name){
		accountID= "P00"+(++idGenerator);
		this.name=name;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAccountID() {
		return accountID;
	}


	public boolean hasPaid() {
		return hasPaid;
	}


	public void setHasPaid(boolean hasPaid) {
		this.hasPaid = hasPaid;
	}


	@Override
	public String toString() {
		return "User [name=" + name + ", accountID=" + accountID + ", hasPaid=" + hasPaid + "]";
	}

}
