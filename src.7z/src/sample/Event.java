package sample;

public class Event {
	private String eventID;
	private double eventCost; // for this event
	
	public Event(String eID, double cost) {
		super();
		this.eventID = eID;
		this.eventCost = cost;
	}

	public String getEventID() {
		return eventID;
	}

	public void setEventID(String eventID) {
		this.eventID = eventID;
	}

	public double getEventCost() {
		return eventCost;
	}

	public void setEventCost(double eventCost) {
		this.eventCost = eventCost;
	}

	@Override
	public String toString() {
		return "Event [eventID=" + eventID + ", eventCost=" + eventCost + "]";
	}
	
	
	
	
	

}
