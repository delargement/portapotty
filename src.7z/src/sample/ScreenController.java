package sample;//display screen

public class ScreenController {
	
	public void displayMessage(Participant p) {
		System.out.println(p);
	}

}
