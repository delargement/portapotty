module mock {
    requires javafx.controls;
    requires javafx.fxml;

    opens sample;

}