package com.example.breedlikerats.model

abstract class Media(
    val posterPath: String,
    val poster: String,
    val releaseDate: String,
    val overview: String,
    val id: Int,
    val title: String,
    val popularity: Double,
    val voteCount: Int,
    val voteAverage: Double,
) {
    val imageUrl = "https://image.tmdb.org/t/p/w500/$posterPath"
}