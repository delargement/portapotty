package com.example.breedlikerats.model


class Movie(
    posterPath: String,
    poster: String,
    releaseDate: String,
    overview: String,
    id: Int,
    title: String,
    popularity: Double,
    voteCount: Int,
    voteAverage: Double,
) : Media(posterPath, poster, releaseDate, overview, id, title, popularity, voteCount, voteAverage){

}
