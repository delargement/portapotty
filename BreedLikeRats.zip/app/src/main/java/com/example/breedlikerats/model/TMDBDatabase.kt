package com.example.breedlikerats.model

import com.beust.klaxon.JsonArray
import com.beust.klaxon.JsonObject
import com.beust.klaxon.Klaxon
import java.net.URL


class SearchResult<T>(val results: JsonArray<JsonObject>, val total_results: Int)

data class Person(val nameN: String)


enum class MediaType{
    TV,MOVIE
}
class TMDBDatabase {
    companion object{
        // API Key included for assessment's sake
        val APIKEY: String = "563e44bc8f4e833a6ebe30b5355b82f8"
//        val klaxon: Klaxon = Klaxon().fieldRenamer(object:FieldRenamer {
//            override fun toJson(fieldName: String) = FieldRenamer.camelToUnderscores(fieldName)
//            override fun fromJson(fieldName: String) = FieldRenamer.underscoreToCamel(fieldName)
//        })

        // e.g. movie?api_key=563e44bc8f4e833a6ebe30b5355b82f8&language=en-US&query=super&page=1&include_adult=false
        val movieBaseURL: String = "https://api.themoviedb.org/3/search/movie?api_key=${APIKEY}&language=en-US&include_adult=false"
        val tvBaseURL: String = "https://api.themoviedb.org/3/search/tv?api_key=${APIKEY}&language=en-US&include_adult=false"

        fun <T> searchDatabase(media: MediaType, query: String, pageNo: Int): SearchResult<T>? =
            Klaxon().parse<SearchResult<T>>(
                URL(
                    (if (media == MediaType.MOVIE) movieBaseURL else tvBaseURL)
                            + "&page=${pageNo}&query=$query"
                ).readText()
            )
    }
}