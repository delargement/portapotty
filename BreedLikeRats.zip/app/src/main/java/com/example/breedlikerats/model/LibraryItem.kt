package com.example.breedlikerats.model

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.breedlikerats.R
import com.squareup.picasso.Picasso


class LibraryItemAdapter(val context: Context, val items: MutableList<Media>) : RecyclerView.Adapter<LibraryItemAdapter.LibraryItemHolder>(){

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LibraryItemHolder =
        LibraryItemHolder(LayoutInflater.from(context).inflate(R.layout.library_element,parent,false))

    override fun onBindViewHolder(holder: LibraryItemHolder, position: Int) = holder.setDetails(items[position])

    override fun getItemCount() = items.size

    class LibraryItemHolder(
        itemView: View
    ) : RecyclerView.ViewHolder(itemView){
//        val code: TextView = itemView.findViewById(R.id.module_code)
//        val grade: TextView = itemView.findViewById(R.id.module_grade)
//        val MC: TextView = itemView.findViewById(R.id.module_MC)
        val thumbnailView: ImageView = itemView.findViewById(R.id.thumbnailView)
        val titleView: TextView = itemView.findViewById(R.id.titleView)

        fun setDetails(media: Media){
            Picasso.get().load(media.imageUrl).into(thumbnailView)
            titleView.text = media.title
        }
    }
}


