package com.example.breedlikerats.ui.library

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.breedlikerats.model.Media

class LibraryViewModel : ViewModel() {
    private val _LibraryItems = MutableLiveData<MutableList<Media>>().apply {
        value = mutableListOf()
    }
    val libraryItems = _LibraryItems
}