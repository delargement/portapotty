public class Memee {

	public static void main(String[] args){
		String pattern = "[a-zA-Z]{3,9}";
		if ("a".matches(pattern))
			System.out.println("few");

	}
}
