package Model;

public class Stats {
}
