package Model;

public class Nutrients {
	private double protein,calories,carbohydrates,fiber,sugar,cholesterol;
	private static final double VOID = 0;

	public Nutrients(){
		this(VOID,VOID,VOID,VOID,VOID,VOID);
	}
	public Nutrients(double protein, double calories, double carbohydrates, double fiber, double sugar, double cholestrol) {
		this.protein = protein;
		this.calories = calories;
		this.carbohydrates = carbohydrates;
		this.fiber = fiber;
		this.sugar = sugar;
		this.cholesterol = cholestrol;
	}

	public void addNutrients(Nutrients nut){
		this.setCalories(calories+nut.getCalories());
		this.setCarbohydrates(carbohydrates+nut.getCarbohydrates());
		this.setCholesterol(cholesterol+nut.getCholesterol());
		this.setFiber(fiber+nut.getFiber());
		this.setProtein(protein+nut.getProtein());
		this.setSugar(sugar+nut.getSugar());
	}

	public double getProtein() {
		return protein;
	}

	public void setProtein(double protein) {
		this.protein = protein;
	}

	public double getCalories() {
		return calories;
	}

	public void setCalories(double calories) {
		this.calories = calories;
	}

	public double getCarbohydrates() {
		return carbohydrates;
	}

	public void setCarbohydrates(double carbohydrates) {
		this.carbohydrates = carbohydrates;
	}

	public double getFiber() {
		return fiber;
	}

	public void setFiber(double fiber) {
		this.fiber = fiber;
	}

	public double getSugar() {
		return sugar;
	}

	public void setSugar(double sugar) {
		this.sugar = sugar;
	}

	public double getCholesterol() {
		return cholesterol;
	}

	public void setCholesterol(double cholesterol) {
		this.cholesterol = cholesterol;
	}
}
