package Model;

import javafx.scene.control.Alert;
import javafx.util.Pair;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class UserInfo {
	private final static int MALE = 0, FEMALE = 1, SEDENTARY = 0, MODERATE = 1, ACTIVE = 2;
	private final static int[] AGERANGE = {2,4,9,14,19,31,51};
	private int age,gender,lifestyle;
	private String CALORIEFILE = "calorieintake.csv";

	public UserInfo(int age, int gender, int lifestyle) {
		this.age = age;
		this.gender = gender;
		this.lifestyle = lifestyle;
	}

	public static int ageGroup(int age){
		for(int i = 0; i < AGERANGE.length-1; ++i){
			if (age < AGERANGE[i+1])
				return i;
		}
		return AGERANGE.length-1;
	}

	public PairInt calorieNeeds(){
		PairInt[][][] data = readData();
		return data[gender][ageGroup(age)][lifestyle];
	}

	public PairInt[][][] readData(){
		PairInt data[][][] = new PairInt[2][AGERANGE.length][3];
		try {
			Scanner inp = new Scanner(new File(CALORIEFILE));
			int n =inp.nextInt();

			for(int i=0;i<1; ++i)
				for(int j=0;j<n;++j){
					int a=inp.nextInt(),b=inp.nextInt();
					for(int k=0;k<3;++k){
						data[i][j][k] = new PairInt(inp.nextInt(),inp.nextInt());
					}
			}
		} catch(FileNotFoundException ex){
			new Alert(Alert.AlertType.ERROR,CALORIEFILE + " not found.").show();
		}
		return data;
	}
}
