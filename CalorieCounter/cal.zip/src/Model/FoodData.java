package Model;

import javafx.scene.control.Alert;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class FoodData {
	private static final String NUTRIENTFILE =  "nutrient.csv", FOODNUTFILE = "food_nutrient.csv",FOODFILE="food.csv";
	public FoodData(){}

	public static Nutrients fetchFoodData(String id){
		Nutrients nut = new Nutrients();
		ArrayList<String[]> list = findLine(0,id,FOODNUTFILE);
		for(var arr: list){

		}
	}
	public NutrientType nutrientIdToType(String id){
		var list = findLine(0,id,NUTRIENTFILE);
	}

	public static String nameToId(String name){
		ArrayList<String[]> list = findLine(2,name,FOODFILE);
		return list.get(0)[0];
	}

	public static ArrayList<String[]> findLine(int idx,String key,String file){
		return findLine(idx, key, file,false);
	}
	public static ArrayList<String[]> findLine(int idx,String key,String file,boolean once){
		ArrayList<String[]> list = new ArrayList<>();
		try {
			Scanner inp = new Scanner(new File(file));
			while(inp.hasNext()){
				String s = inp.nextLine();
				String tok[]=s.split("[,]");
				if (tok[idx].equals(key)){
					list.add(tok);
					if (once)
						return list;
				}
			}
		} catch(FileNotFoundException ex){
			new Alert(Alert.AlertType.ERROR,file + " not found").show();
		}
		return list;
	}
}
