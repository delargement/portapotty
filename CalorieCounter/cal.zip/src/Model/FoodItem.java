package Model;

public class FoodItem extends Food {

	public FoodItem(String name,Nutrients nutrients){
		super(name,nutrients);
	}
}
