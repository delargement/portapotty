package Model;

public class UserData {

}
