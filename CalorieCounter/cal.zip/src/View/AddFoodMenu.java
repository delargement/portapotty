package View;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class AddFoodMenu {
	public AddFoodMenu(){}

	public void showMenu() throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("AddFood.fxml"));
		Stage menu = new Stage();
		menu.setTitle("Hello World");
		menu.setScene(new Scene(root, 500, 500));
		menu.show();
	}
}
