package View;

import javafx.scene.control.Button;
import javafx.scene.shape.Rectangle;

import java.util.ArrayList;

public class infoBox extends Rectangle {
	private ArrayList<Object> elements;
}
