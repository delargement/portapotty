package View;

import Model.Food;
import Model.FoodSet;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class FoodBox extends StackPane {
	private Food food;
	private final static double WIDTH =500,HEIGHT=500;

	public FoodBox(double width, double height, Color color, Food food){
		super();
		this.food = food;
		super.setWidth(width);
		super.setHeight(height);

		Rectangle rect = new Rectangle(width,height);
		rect.setFill(color);
		Label name = new Label(food.getName());
		Button edit = new Button("Edit");
		Button delete = new Button("X");

		super.getChildren().addAll(rect,edit,delete);
		edit.setAlignment(Pos.BOTTOM_LEFT);
		delete.setAlignment(Pos.BOTTOM_RIGHT);
	}

	public FoodBox(Color color, FoodSet foodSet){
		this(WIDTH,HEIGHT,color,foodSet);
	}

	public Food getFood() {
		return food;
	}

	public void setFood(Food food) {
		this.food= food;
	}
}
