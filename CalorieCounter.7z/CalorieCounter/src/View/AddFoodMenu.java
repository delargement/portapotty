package View;

import Model.Food;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.util.ArrayList;

public class AddFoodMenu extends Application {

	public void start(Stage menu) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("AddFood.fxml"));
		menu.setTitle("Hello World");
		menu.setScene(new Scene(root, 870, 540));
		menu.show();
	}

}