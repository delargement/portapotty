package View;

import Model.PairInt;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class UserInfo {
	public final static int MALE = 0, FEMALE = 1, SEDENTARY = 0, MODERATE = 1, ACTIVE = 2;
	private final static int[] AGERANGE = {2,4,9,14,19,31,51};
	private int age,gender,lifestyle,weight;
	private static final String CALORIEFILE = "src/DataFiles/calorieintake.csv", INFOFILE = "src/DataFiles/userInfo.csv";

	public UserInfo(int age, int gender, int lifestyle,int weight) {
		this.age = age;
		this.gender = gender;
		this.lifestyle = lifestyle;
		this.weight=weight;
	}

	public UserInfo(){
		updateFromFile();
	}

	public static int ageGroup(int age){
		for(int i = 0; i < AGERANGE.length-1; ++i){
			if (age < AGERANGE[i+1])
				return i;
		}
		return AGERANGE.length-1;
	}

	public PairInt calorieNeeds(){
		PairInt[][][] data = readData();
		return data[gender][ageGroup(age)][lifestyle];
	}

	public PairInt[][][] readData(){
		PairInt data[][][] = new PairInt[2][AGERANGE.length][3];
		try {
			Scanner inp = new Scanner(new File(CALORIEFILE));
			int n =inp.nextInt();

			for(int i=0;i<1; ++i)
				for(int j=0;j<n;++j){
					int a=inp.nextInt(),b=inp.nextInt();
					for(int k=0;k<3;++k){
						data[i][j][k] = new PairInt(inp.nextInt(),inp.nextInt());
					}
			}
		} catch(FileNotFoundException ex){
			new Alert(Alert.AlertType.ERROR,CALORIEFILE + " not found.").show();
		}
		return data;
	}
	@Override
	public String toString() {
		return age + "," + gender + "," + lifestyle + "," + weight;
	}

	public void getUserInfo() {
		Stage stage = new Stage();

		try {
			Parent root = FXMLLoader.load(getClass().getResource("getUserInfo.fxml"));
			stage.setTitle("Add Preset");
			stage.setScene(new Scene(root, 400, 400));
			stage.showAndWait();
		} catch (IOException ex){
			new Alert(Alert.AlertType.ERROR,"Error loading getUserInfo.fxml").showAndWait();
		}
	}

	public void writeFileDefaults(){
		try {
			PrintWriter pw = new PrintWriter(INFOFILE);
			pw.println("25,0,0,50");
			pw.close();
		} catch (FileNotFoundException ex){
			new Alert(Alert.AlertType.ERROR, INFOFILE + " not found").showAndWait();
		}
	}

	public static boolean isUserFileEmpty(){
		try {
			Scanner inp = new Scanner(new File(INFOFILE));
			boolean ans = !inp.hasNext();
			inp.close();
			return ans;
		} catch (FileNotFoundException ex){
			new Alert(Alert.AlertType.ERROR,INFOFILE + " not found").showAndWait();
		}
		return true;
	}
	public void updateFromFile(){
		try{
			Scanner inp = new Scanner(new File(INFOFILE));
			if(!inp.hasNext()){
				getUserInfo();
				if (!inp.hasNext()){
					writeFileDefaults();
				}
			}
			String tok[] = inp.nextLine().split(",");
			setAge(Integer.parseInt(tok[0]));
			setGender(Integer.parseInt(tok[1]));
			setLifestyle(Integer.parseInt(tok[2]));
			setWeight(Integer.parseInt(tok[3]));
			inp.close();
		} catch (FileNotFoundException ex){
			new Alert(Alert.AlertType.ERROR,INFOFILE + " not found").showAndWait();
		}
	}

	public void writeInfo(){
		try {
			PrintWriter pw = new PrintWriter(INFOFILE);
			pw.println(this);
			pw.close();
		} catch (FileNotFoundException ex){
			new Alert(Alert.AlertType.ERROR,INFOFILE + " not found.").showAndWait();
		}
	}
	// as little as possible
	public double optimalCholesterol(){
		return 0.05*optimalCalories();
	}
	public double optimalCarbohydrates(){
		return 0.55*optimalCalories();
	}
	// as little as possible
	public double optimalSugar(){
		if (gender==MALE)
			return 37.5;
		else
			return 25;
	}
	public double optimalCalories(){
		return calorieNeeds().second;
	}
	public double optimalFiber(){
		if (gender==MALE)
			return 32;
		else
			return 25;
	}
	public double optimalProtein(){
		if (lifestyle == ACTIVE)
			return 1.2*weight;
		else
			return 0.8*weight;
	}
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getGender() {
		return gender;
	}

	public void setGender(int gender) {
		this.gender = gender;
	}

	public int getLifestyle() {
		return lifestyle;
	}

	public void setLifestyle(int lifestyle) {
		this.lifestyle = lifestyle;
	}
		public int getWeight () {
			return weight;
		}

		public void setWeight ( int weight){
			this.weight = weight;
		}
	}
