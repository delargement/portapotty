package View;

import Model.Food;
import Model.FoodSet;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.util.Random;

public class FoodBox extends AnchorPane{
	private Food food;
	private final static double WIDTH =100,HEIGHT=100;
	private Rectangle rect;
	private Button delete;
	private Label name;
	private static final Color[] possibleColors = {Color.IVORY,Color.GOLD,Color.AQUA,Color.INDIANRED,Color.LAVENDER};

	public FoodBox(double width, double height, Color color, Food food){
		super();
		this.food = food;
		super.setWidth(width);
		super.setHeight(height);

		rect = new Rectangle(width,height);
		rect.setFill(color);
		name = new Label(food.getName());
		delete = new Button("X");

		super.getChildren().addAll(rect,delete,name);
		name.setMinSize(Region.USE_PREF_SIZE, Region.USE_PREF_SIZE);
		name.relocate(width/2,height/2);
		delete.relocate(width/5.0,4.0/5*height);
	}

	public static Color randomColor(){
		return possibleColors[new Random().nextInt(possibleColors.length)];
	}

	public FoodBox(Color color, Food food){
		this(WIDTH,HEIGHT,color,food);
	}

	public FoodBox(Food food){
		this(randomColor(),food);
	}

	public Food getFood() {
		return food;
	}

	public void setFood(Food food) {
		this.food= food;
	}

	public void setColor(Color color){
		rect.setFill(color);
	}

	public Rectangle getRect() {
		return rect;
	}

	public void setRect(Rectangle rect) {
		this.rect = rect;
	}


	public Button getDelete() {
		return delete;
	}

	public void setDelete(Button delete) {
		this.delete = delete;
	}

	public Label getName() {
		return name;
	}

	public void setName(Label name) {
		this.name = name;
	}
}
