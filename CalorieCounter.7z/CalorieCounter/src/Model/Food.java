package Model;

public abstract class Food {
	private String name;
	private Nutrients nutrients;

	public Food(String name, Nutrients nutrients) {
		this.name = name;
		this.nutrients = nutrients;
	}

	public Food(String name) {
		this(name, new Nutrients());
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Nutrients getNutrients(){
		return nutrients;
	}
	public void setNutrients(Nutrients nutrients){
		this.nutrients=nutrients;
	}

	@Override
	public String toString() {
		return name +"," + nutrients;

	}
}

