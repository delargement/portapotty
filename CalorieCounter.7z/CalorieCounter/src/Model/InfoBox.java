package Model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;

public class InfoBox {
	enum InfoType{STREAK,AVERAGE,DISCOVERY}
	private static ArrayList<NutrientType.Type> nutrientTypes = (ArrayList<NutrientType.Type>)
			Arrays.asList(NutrientType.getTypes());
	private InfoType type;
	private NutrientType nutrientType;
	public InfoBox(InfoType type,NutrientType nutrientType){
		this.type = type;
		this.nutrientType = nutrientType;
	}

	public static InfoBox generateInfoBox(){
		InfoType arr[] = {InfoType.STREAK,InfoType.AVERAGE,InfoType.DISCOVERY};

	}
}
