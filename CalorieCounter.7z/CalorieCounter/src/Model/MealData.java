package Model;

import javafx.scene.control.Alert;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class MealData {
	private static ArrayList<Meal> meals = new ArrayList<>();
	private static final String MEALFILE = "meal_list.csv";

	public static void writeMeals(){
		try{
			PrintWriter pw = new PrintWriter(MEALFILE);
			for(Meal m : meals){
				pw.println(m.getDateTime() + "," + m.getFoodSets());
			}
		} catch(FileNotFoundException ex){
			new Alert(Alert.AlertType.ERROR,MEALFILE + " not found.").showAndWait();
		}
	}

	public static ArrayList<Meal> readMeals(){
		ArrayList<Meal> meals = new ArrayList<>();
		try{
			Scanner inp = new Scanner(new File(MEALFILE));

		} catch(FileNotFoundException ex){
			new Alert(Alert.AlertType.ERROR,MEALFILE + " not found").showAndWait();
		}
		return meals;
	}

	public static ArrayList<Meal> getMeals() {
		return meals;
	}

	public static void setMeals(ArrayList<Meal> meals) {
		MealData.meals = meals;
	}
}
