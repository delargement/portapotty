package Model;

import javafx.util.Pair;

public class PairInt{
	public int first,second;
	public PairInt(int first,int second){
		this.first = first; this.second = second;
	}
}
