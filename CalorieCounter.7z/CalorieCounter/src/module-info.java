module CalorieCounter {
	requires javafx.controls;
	requires javafx.fxml;

	opens Controller;
	opens Main;
	opens View;
	opens Model;
}