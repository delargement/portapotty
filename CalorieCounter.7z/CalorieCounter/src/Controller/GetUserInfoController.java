package Controller;

import View.UserInfo;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class GetUserInfoController implements Initializable {
	@FXML
	private Button doneBtn;

	@FXML
	private ComboBox<String> genderBox;

	@FXML
	private ComboBox<String> lifestyleBox;

	@FXML
	private TextField ageField;

	@FXML
	private TextField weightField;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		genderBox.getItems().addAll(
				"Male","Female"
		);
		genderBox.getSelectionModel().selectFirst();
		lifestyleBox.getItems().addAll(
				"Sedentary","Moderate","Active"
		);
		lifestyleBox.getSelectionModel().selectFirst();
	}

	public void handleDone(ActionEvent actionEvent){
		String genderInp = genderBox.getValue();
		int gender,lifestyle,age,weight;
		Alert invInp = new Alert(Alert.AlertType.WARNING,"Invalid input");
		if (genderInp.equals("Male")){
			gender = UserInfo.MALE;
		} else if (genderInp.equals("Female")){
			gender = UserInfo.FEMALE;
		} else{
			invInp.showAndWait();
			return;
		}
		String lifestyleInp = lifestyleBox.getValue();
		if (lifestyleInp.equals("Sedentary")){
			lifestyle=UserInfo.SEDENTARY;
		} else if (lifestyleInp.equals("Moderate")){
			lifestyle= UserInfo.MODERATE;
		} else if (lifestyleInp.equals("Active")){
			lifestyle=UserInfo.ACTIVE;
		}else{
			invInp.showAndWait();
			return;
		}
		try{
			age = Integer.parseInt(ageField.getText());
			if (age <=0 || age >= 200) {
				invInp.showAndWait();
				return;
			}
		} catch (NumberFormatException ex){
			invInp.showAndWait();
			return;
		}
		try{
			weight=Integer.parseInt(weightField.getText());
			if (weight <=0) {
				invInp.showAndWait();
				return;
			}
		} catch (NumberFormatException ex) {
			invInp.showAndWait();
			return;
		}
		UserInfo info = new UserInfo(age,gender,lifestyle,weight);
		info.writeInfo();
		((Stage) doneBtn.getScene().getWindow()).close();
		return;
	}
}
