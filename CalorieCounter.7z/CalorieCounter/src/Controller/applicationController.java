package Controller;

import Model.*;
import View.UserInfo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.*;

public class applicationController implements Initializable {
	@FXML
	private TableView<Meal> reportTable;

	@FXML
	private TableColumn<Meal,String> reportDateCol;

	@FXML
	private TableColumn<Meal,String> reportMealCol;

	@FXML
	private DatePicker fromPicker;

	@FXML
	private DatePicker toPicker;

	@FXML
	private ComboBox<String> nutrientCombo;

	@FXML
	private Label ratingText;

	@FXML
	private Label dailyIntakeText;

	@FXML
	private Label reportUnits1;

	@FXML
	private Label optimalIntakeText;

	@FXML
	private Label reportUnits2;

	@FXML
	private Button quickAddMealBtn;

	@FXML
	private DatePicker graphFromPicker;

	@FXML
	private DatePicker graphToPicker;

	@FXML
	private LineChart<?, ?> lineGraph;

	@FXML
	private ComboBox<?> graphNutrientCombo;

	ObservableList<Meal>   reportData = FXCollections.observableArrayList();
	ObservableList<String> nutrientTypes = FXCollections.observableArrayList(
			"protein","energy","carbohydrates","fiber","sugar","cholesterol"
	);
	UserInfo               userInfo;


	public String generateRating(double score,double goal){
		double p = Math.abs(score-goal)/goal*100;
		if(p<=5){
			return "Good job!";
		} else if (p <= 25){
			return "Nice";
		} else if (p<=50){
			return "Decent";
		} else if (p <= 75)
			return "Not half bad";
		else
			return "You could do better";
	}



	public void initialize(URL location, ResourceBundle resources) {
		reportDateCol.setCellValueFactory(new PropertyValueFactory<Meal,String>("formattedDateTime"));
		reportMealCol.setCellValueFactory(new PropertyValueFactory<Meal,String>("formattedDateTime"));
		generateReportTable(LocalDate.MIN,LocalDate.MAX);
		nutrientCombo.setItems(nutrientTypes);
		userInfo = new UserInfo();
	}
	public void selGraph(ActionEvent actionEvent){
	    reportTable.setVisible(false);
	   	lineGraph.setVisible(true);
	}
	public void selTable(ActionEvent actionEvent){
		reportTable.setVisible(true);
		lineGraph.setVisible(false);
	}



	public void quickAddMeal(ActionEvent actionEvent){
		try {
			Stage menu = new Stage();
			Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("View/AddFood.fxml"));
			menu.setTitle("Hello World");
			menu.setScene(new Scene(root, 880, 640));
			menu.show();
		} catch (IOException ex){
			new Alert(Alert.AlertType.ERROR,"addfood.fxml not found").showAndWait();
		}
	}

	public void handleFromPicker(ActionEvent actionEvent){
		toPicker.setDisable(false);
	}
	public void handleToPicker(ActionEvent actionEvent){
		try{
			generateReportTable(fromPicker.getValue(),toPicker.getValue());
		} catch(NullPointerException ex){
			new Alert(Alert.AlertType.WARNING,"Please select date").showAndWait();
		}
	}
	public void generateReportTable(LocalDate from,LocalDate to){
		reportData.clear();
		ArrayList<Meal> meals = MealData.getMeals();
		Collections.sort(meals);
		LocalDateTime start = LocalDateTime.of(from,LocalTime.MIN), end = LocalDateTime.of(to,LocalTime.MAX);

		// binary search to find earliest meal such it occurred after LocalDateTime start - O(lgn)
		int s=0,e=meals.size()-1,max_ind=0;
		while(s < e){
			int mid = (s+e)/2;
			if (meals.get(mid).getDateTime().isBefore(start)){
				s = mid+1;
			} else{
				max_ind = Math.max(max_ind,mid);
				e = mid;
			}
		}
		for(int i = max_ind; i <meals.size(); ++i){
			LocalDateTime ldt = meals.get(i).getDateTime();
			if (ldt.isAfter(end))
				break;
			reportData.add(meals.get(i));
		}
		reportTable.setItems(reportData);
	}
	public void generateGraph(NutrientType nt){
		LocalDateTime now = LocalDateTime.now();
		XYChart.Series series = new XYChart.Series();
		TreeMap<Integer,Double> mp = new TreeMap<Integer, Double>();
		TreeSet<Integer>  set = new TreeSet<>();
	    for(int i = 0; i < reportData.size(); ++i){
	        double amt = 0;
	        var fs = reportData.get(i).getFoodSets();
	    	for (var v: fs) {
	    		amt += NutrientType.amountFromType(v.getNutrients(),nt.getType());
			}
	    	int key = (int)ChronoUnit.DAYS.between(reportData.get(i).getDateTime(),now);
	    	set.add(key);
	    	mp.put(key,mp.getOrDefault(key,(double)0)+amt);
		}
	    for(var v: set){
	    	series.getData().add(new XYChart.Data<>(v,mp.get(v)));
	    }
	}

	public void selNutrientType(ActionEvent actionEvent){
		if (!nutrientCombo.getValue().equals("") && reportData.size() != 0){
			NutrientType nt = new NutrientType(NutrientType.nameToType(nutrientCombo.getValue()));
			reportUnits1.setText(nt.getUnit_name());
			reportUnits2.setText(nt.getUnit_name());
			double sum=0;
			for(int i = 0; i < reportData.size(); ++i){
				for (var fs: reportData.get(i).getFoodSets()){
					sum += NutrientType.amountFromType(fs.getNutrients(),nt.getType());
				}
			}
			int avg = (int) sum/reportData.size();
			dailyIntakeText.setText(avg + "");

			optimalIntakeText.setText((nt.getType()== NutrientType.Type.CARBOHYDRATES || nt.getType()== NutrientType.Type.SUGAR ? "<":"")
					+ NutrientType.getOptimal(nt.getType(),userInfo)+"");
		}
	}


}
