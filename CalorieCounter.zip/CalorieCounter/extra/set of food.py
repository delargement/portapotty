
infile = open("food.csv","r")
out = open("out.csv","w")

s = set()
for i in infile.readlines():
    lst = i.split(",")
    s.add(lst[2])

for i in s:
    out.write(i+"\n");
infile.close()
out.close()
