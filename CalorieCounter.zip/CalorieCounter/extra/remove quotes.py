
infile = open("out.csv","r")
out = open("out2.csv","w")


for i in infile.readlines():
    out.write(i.replace("\"",""));

out.close()
