
infile1  = open("food.csv","r");
s = set();
m = {};
for i in infile1.readlines():
    lst = list(i.split(","));
    if not lst[0].isdigit():
        print(i)
        continue
    s.add(int(lst[0]))
    m[int(lst[0])] = i;
infile1.close()


inf2 = open("food_nutrient.csv","r")
out = open("out.csv","w")
out2 = open("out2.csv","w")

k=0
for i in inf2.readlines():
    lst = list(i.split(","))
    st = lst[1][1:-1]
    if not st.isdigit():
        continue
    if int(st) in s:
        out.write(i.replace("\"",""))
        out2.write(m[int(st)])


inf2.close()
out.close()
out2.close()
