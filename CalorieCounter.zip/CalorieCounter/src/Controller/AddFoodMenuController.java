package Controller;

import Model.*;
import View.AddPresetMenu;
import View.FoodBox;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.security.Key;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;

public class AddFoodMenuController implements Initializable {


	@FXML
	private HBox selBox;
	@FXML
	private TextField searchBar;
	@FXML
	private TableView<String> foodSettable;
	@FXML
	private TableColumn<String, String> foodCol;
	@FXML
	private RadioButton keywordsRadio;
	@FXML
	private RadioButton regexRadio;
	@FXML
	private Button createPresetBtn;
	@FXML
	private Button createFoodBtn;
	@FXML
	private FlowPane presetPane;
	@FXML
	private Button doneBtn;

	ObservableList<String> data = FXCollections.observableArrayList();

	public void initialize(URL location, ResourceBundle resources) {
		data.addAll(FoodData.fetchFoodList());
		foodCol.setCellValueFactory(s -> new SimpleStringProperty(s.getValue()));
		foodSettable.setItems(data);

		generatePresetPane();
	}

	public void searchFood(KeyEvent e){
		if (e.getCode() != KeyCode.ENTER)
			return;
		String s = searchBar.getText();
		s = s.toLowerCase();
		ArrayList<String> newData = new ArrayList<>();
		ArrayList<String> list = FoodData.fetchFoodList();
		for (String v : list) {
			if (keywordsRadio.isSelected()){
				String tok[] = s.split("[ ]");
				boolean quit = false;
				for(String key: tok){
					if (!v.contains(key)){
						quit=true;
						break;
					}
				}
				if(quit)
					continue;
				newData.add(v);
			} else if (regexRadio.isSelected()){
				if (v.matches(".*" + s + ".*")) {
					newData.add(v);
				}
			}
		}
		data.clear();
		data.addAll(newData);
	}

	public void addFoodBox(MouseEvent event){
		if (event.getButton().equals(MouseButton.PRIMARY) && event.getClickCount() >= 2) {
			String foodName = foodSettable.getSelectionModel().getSelectedItem();
			String id = FoodData.foodNameToId(foodName);
			System.out.println(id);
			FoodBox box = new FoodBox(FoodBox.randomColor(), new FoodItem(foodName,id, FoodData.fetchFoodData(id)));
			selBox.getChildren().add(box);
			box.getDelete().setOnAction(e -> {
				selBox.getChildren().remove(box);
			});
		}
	}

	public void generatePresetPane(){
		ArrayList<FoodSet> foodSets = FoodData.readPresets();
		for(FoodSet fs: foodSets){
			FoodBox box = new FoodBox(fs);
			presetPane.getChildren().add(box);
			box.getDelete().setOnAction(e -> {
				presetPane.getChildren().remove(box);
			});
		}
	}
	public void handleCreatePreset(ActionEvent actionEvent) throws IOException {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/View/AddPreset.fxml"));
			Stage menu = new Stage();
			menu.setTitle("Add Preset");
			menu.setScene(new Scene(root, 870, 540));
			menu.showAndWait();
		} catch (IOException ex){
			new Alert(Alert.AlertType.ERROR, "FXML file not found").showAndWait();
		}
//		AddPresetMenu.launch();
	}
	public void handleCreateFood(ActionEvent actionEvent){
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/View/CreateFood.fxml"));
			Stage menu = new Stage();
			menu.setTitle("Create food item");
			menu.setScene(new Scene(root, 870, 540));
			menu.showAndWait();
			initialize(null,null);
		} catch (IOException ex){
			new Alert(Alert.AlertType.ERROR, "FXML file not found").showAndWait();
		}
	}

	public void handleDone(ActionEvent actionEvent){
		if (selBox.getChildren().isEmpty()){
			new Alert(Alert.AlertType.CONFIRMATION,"Nothing selected").showAndWait();
			return;
		}
		ArrayList<FoodSet> foodSets = new ArrayList<>();
		for(var v: selBox.getChildren()){
			Food f = ((FoodBox) v).getFood();
			if (f instanceof FoodItem){
				System.out.println((FoodItem) f);
				var list = new ArrayList<FoodItem>();
				list.add((FoodItem) f);
				foodSets.add(new FoodSet(f.getName(),list));
			} else {
				foodSets.add((FoodSet) f);
			}
		}
		Meal m = new Meal(LocalDateTime.now(),foodSets);
		MealData.getMeals().add(m);
		MealData.writeMeals();
		((Stage) doneBtn.getScene().getWindow()).close();
	}

}
