package Controller;

import Model.*;
import View.AddPresetMenu;
import View.FoodBox;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.security.Key;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;

public class AddFoodMenuController implements Initializable {


	@FXML
	private HBox selBox;
	@FXML
	private TextField searchBar;
	@FXML
	private TableView<String> foodSettable;
	@FXML
	private TableColumn<String, String> foodCol;
	@FXML
	private RadioButton keywordsRadio;
	@FXML
	private RadioButton regexRadio;
	@FXML
	private Button createPresetBtn;
	@FXML
	private Button createFoodBtn;
	@FXML
	private FlowPane presetPane;
	@FXML
	private Button doneBtn;
	@FXML
	private Tab menuTab;
	@FXML
	private Tab presetTab;

	private static ResourceBundle rb=ApplicationController.getRb();
	ObservableList<String> data = FXCollections.observableArrayList();

	public void initialize(URL location, ResourceBundle resources) {
		data.clear();
		data.addAll(FoodData.fetchFoodList());
		foodCol.setCellValueFactory(s -> new SimpleStringProperty(s.getValue()));
		foodSettable.setItems(data);
		generatePresetPane();
		if (menuTab!=null)
			menuTab.setText(rb.getString("menu"));
		if (presetTab!=null)
			presetTab.setText(rb.getString("presets"));
		keywordsRadio.setText(rb.getString("keywords"));
		foodCol.setText(rb.getString("food"));
		if (createFoodBtn!=null)
			createFoodBtn.setText(rb.getString("create new food"));
		if (createPresetBtn!=null)
			createPresetBtn.setText(rb.getString("create new preset"));
		doneBtn.setText(rb.getString("done"));
	}

	public void searchFood(KeyEvent e){
		if (e.getCode() != KeyCode.ENTER)
			return;
		String s = searchBar.getText();
		s = s.toLowerCase();
		ArrayList<String> newData = new ArrayList<>();
		ArrayList<String> list = FoodData.fetchFoodList();
		for (String v : list) {
			if (keywordsRadio.isSelected()){
				String tok[] = s.split("[ ]");
				boolean quit = false;
				for(String key: tok){
					if (!v.contains(key)){
						quit=true;
						break;
					}
				}
				if(quit)
					continue;
				newData.add(v);
			} else if (regexRadio.isSelected()){
				if (v.matches(".*" + s + ".*")) {
					newData.add(v);
				}
			}
		}
		data.clear();
		data.addAll(newData);
	}

	public void mouseClickTable(MouseEvent event){
		if (event.getButton().equals(MouseButton.PRIMARY) && event.getClickCount() >= 2) {
			addFoodBox();
		} else if (event.getButton().equals(MouseButton.SECONDARY)) {
			showNutrients();
		}
	}
	public void addFoodBox() {
			String foodName = foodSettable.getSelectionModel().getSelectedItem();
			String id = FoodData.foodNameToId(foodName);
//			System.out.println(id);
			FoodBox box = new FoodBox(FoodBox.randomColor(), new FoodItem(foodName, id, FoodData.fetchFoodData(id)));
			selBox.getChildren().add(box);
			box.getDelete().setOnAction(e -> {
				selBox.getChildren().remove(box);
			});
	}

	public void showNutrients(){
			String foodName = foodSettable.getSelectionModel().getSelectedItem();
			Nutrients n = 	FoodData.fetchFoodData(FoodData.foodNameToId(foodName));
			String s =rb.getString("protein") + ": " + n.getProtein() + new NutrientType(NutrientType.Type.PROTEIN).getUnit_name()+","+
					rb.getString("sugar") + ": " + n.getSugar() + new NutrientType(NutrientType.Type.SUGAR).getUnit_name() +", " +
					rb.getString("cholesterol") + ": " + n.getCholesterol() + new NutrientType(NutrientType.Type.CHOLESTEROL).getUnit_name() +", " +
					rb.getString("fiber") + ": " + n.getFiber() + new NutrientType(NutrientType.Type.FIBER).getUnit_name() +", " +
					rb.getString("carbohydrates") + ": " + n.getCarbohydrates() + new NutrientType(NutrientType.Type.CARBOHYDRATES).getUnit_name() +", " +
					rb.getString("energy") + ": " + n.getEnergy() + new NutrientType(NutrientType.Type.ENERGY).getUnit_name();
			new Alert(Alert.AlertType.INFORMATION,s).showAndWait();
	}

	public void generatePresetPane(){
		ArrayList<FoodSet> foodSets = FoodData.readPresets();
		if (presetPane!=null)
			presetPane.getChildren().clear();
		if (presetPane==null)
			presetPane=new FlowPane();
		for(FoodSet fs: foodSets){
			FoodBox box = new FoodBox(fs);
			presetPane.getChildren().add(box);
			box.giveSelectButton();
			box.getDelete().setOnAction(e -> {
				presetPane.getChildren().remove(box);
				FoodData.getPresets().remove((FoodSet) box.getFood());
				FoodData.writePresets();
			});
			box.getSelect().setOnAction(e ->{
				FoodBox fb = new FoodBox(box.getWidth(),box.getHeight(),box.getColor(),box.getFood());
				selBox.getChildren().add(fb);
				fb.getDelete().setOnAction(ev -> {
					selBox.getChildren().remove(fb);
				});
			});
		}
	}

	public void handleCreatePreset(ActionEvent actionEvent) throws IOException{
		int n = FoodData.getPresets().size();
		Parent root = FXMLLoader.load(getClass().getResource("/View/AddPreset.fxml"));
		Stage menu = new Stage();
		menu.setTitle("Add Preset");
		menu.initModality(Modality.APPLICATION_MODAL);
		menu.getIcons().add(new Image("file:src/DataFiles/cheese.png"));
		menu.setScene(new Scene(root, 870, 580));
		menu.showAndWait();
		if (FoodData.getPresets().size()>n){
			FoodSet fs = FoodData.getPresets().get(FoodData.getPresets().size()-1);
			FoodBox box = new FoodBox(fs);
			box.giveSelectButton();
			presetPane.getChildren().add(box);
			box.getDelete().setOnAction(e -> {
				presetPane.getChildren().remove(box);
				FoodData.getPresets().remove((FoodSet) box.getFood());
				FoodData.writePresets();
			});
			box.getSelect().setOnAction(e ->{
				FoodBox fb = new FoodBox(box.getWidth(),box.getHeight(),box.getColor(),box.getFood());
				selBox.getChildren().add(fb);
				fb.getDelete().setOnAction(ev -> {
					selBox.getChildren().remove(fb);
				});
			});
		}
//		AddPresetMenu.launch();
	}
	public void handleCreateFood(ActionEvent actionEvent) throws IOException{
			Parent root = FXMLLoader.load(getClass().getResource("/View/CreateFood.fxml"));
			Stage menu = new Stage();
			menu.setTitle(ApplicationController.getRb().getString("Create food item"));
			menu.initModality(Modality.APPLICATION_MODAL);
			menu.getIcons().add(new Image("file:src/DataFiles/cheese.png"));
			menu.setScene(new Scene(root, 1059, 630));
			menu.showAndWait();
			initialize(null,null);
	}

	public void handleDone(ActionEvent actionEvent){
		if (selBox.getChildren().isEmpty()){
			new Alert(Alert.AlertType.WARNING,ApplicationController.getRb().getString("nothing selected")).showAndWait();
			return;
		}
		ArrayList<FoodSet> foodSets = new ArrayList<>();
		for(var v: selBox.getChildren()){
			Food f = ((FoodBox) v).getFood();
			if (f instanceof FoodItem){
//				System.out.println((FoodItem) f);
				var list = new ArrayList<FoodItem>();
				list.add((FoodItem) f);
				foodSets.add(new FoodSet(f.getName(),list));
			} else {
				foodSets.add((FoodSet) f);
			}
		}
		Meal m = new Meal(LocalDateTime.now(),foodSets);
		MealData.setMeals(MealData.readMeals());
		MealData.getMeals().add(m);
		MealData.writeMeals(false);
		((Stage) doneBtn.getScene().getWindow()).close();
	}

}
