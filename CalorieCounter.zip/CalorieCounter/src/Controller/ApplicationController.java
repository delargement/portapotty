package Controller;

import Model.*;
import View.InfoBox;
import Model.UserInfo;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static java.time.temporal.ChronoUnit.DAYS;

public class ApplicationController implements Initializable {
	@FXML
	private TableView<Meal> reportTable;

	@FXML
	private TableColumn<Meal,String> reportDateCol;

	@FXML
	private TableColumn<Meal,String> reportMealCol;

	@FXML
	private DatePicker fromPicker;

	@FXML
	private DatePicker toPicker;

	@FXML
	private ComboBox<String> nutrientCombo;

	@FXML
	private Label ratingText;

	@FXML
	private Label dailyIntakeText;

	@FXML
	private Label reportUnits1;

	@FXML
	private Label optimalIntakeText;

	@FXML
	private Label reportUnits2;

	@FXML
	private Label whatLabel;

	@FXML
	private Button quickAddMealBtn;

	@FXML
	private LineChart<String, Number> lineGraph;

	@FXML
	private FlowPane statFlowPane;

	@FXML
	private Label fromLbl;

	@FXML
	private Label toLbl;

	@FXML
	private Label aveLbl;

	@FXML
	private Label ratingLbl;

	@FXML
	private Label dailyIntakelbl;

	@FXML
	private Label optIntakeLbl;

	@FXML
	private RadioButton tableRadio;

	@FXML
	private RadioButton graphRadio;

	@FXML
	private Button changeSettingsBtn;

	@FXML
	private Tab dashTab;
	@FXML
	private Tab repTab;
	@FXML
	private Tab statTab;
	@FXML
	private Tab settingsTab;
	@FXML
	private Label graphInfoLbl;
	@FXML
	private NumberAxis bottomAxis;


	private static boolean initialised =false;
	private static Locale tamilLocale = new Locale("tl","IN"),englishLocale=new Locale("en","US");

	private static ResourceBundle tl = ResourceBundle.getBundle("messageBundle",tamilLocale),
			en = ResourceBundle.getBundle("messageBundle",englishLocale);
	private static Locale userLocale = englishLocale;
	private static ResourceBundle rb = en;

	ObservableList<Meal>   reportData = FXCollections.observableArrayList();
	ObservableList<String> nutrientTypes = FXCollections.observableArrayList(
			rb.getString("protein"),rb.getString("energy"),rb.getString("carbohydrates"),rb.getString("fiber"),rb.getString("sugar"),rb.getString("cholesterol")
	);
	UserInfo               userInfo;
	boolean playStats=false;


	public void initialize(URL location, ResourceBundle resources) {
		reportDateCol.setCellValueFactory(new PropertyValueFactory<Meal,String>("humanFormattedDateTime"));
		reportMealCol.setCellValueFactory(new PropertyValueFactory<Meal,String>("formattedFoodSets"));
//		generateReportTable(LocalDate.MIN,LocalDate.MAX);
		initReportTable();
		nutrientCombo.setItems(nutrientTypes);
		userInfo = new UserInfo();
		statFlowPane.setPadding(new Insets(20,20,20,20));
		statFlowPane.setHgap(20);
		statFlowPane.setVgap(20);
		initialised=true;

	}

	public void toTamil(ActionEvent actionEvent){
		userLocale = tamilLocale;
		rb = tl;
		translate(rb);
		statFlowPane.getChildren().clear();
		for(int i = 0; i < nutrientTypes.size();++i){
			nutrientTypes.set(i,rb.getString(nutrientTypes.get(i)));
		}
		nutrientCombo.setItems(nutrientTypes);
	}
	public void toEnglish(ActionEvent actionEvent){
		userLocale=englishLocale;
		rb=en;
		translate(rb);
		statFlowPane.getChildren().clear();
		for(int i = 0; i < nutrientTypes.size();++i){
			nutrientTypes.set(i,NutrientType.getTypes()[i].name().toLowerCase());
		}
		nutrientCombo.setItems(nutrientTypes);
	}
	public void translate(ResourceBundle rb){
		quickAddMealBtn.setText(rb.getString("quick add meal"));
		whatLabel.setText(rb.getString("what did you have today"));
		fromLbl.setText(rb.getString("from"));
		toLbl.setText(rb.getString("to"));
		reportDateCol.setText(rb.getString("date"));
		reportMealCol.setText(rb.getString("meal"));
		ratingLbl.setText(rb.getString("rating")+":");
		aveLbl.setText(rb.getString("average daily nutritional intake"));
		dailyIntakelbl.setText(rb.getString("daily intake")+":");
		optIntakeLbl.setText(rb.getString("optimal intake")+":");
		tableRadio.setText(rb.getString("table"));
		graphRadio.setText(rb.getString("graph"));
		changeSettingsBtn.setText(rb.getString("change user settings"));
		bottomAxis.setLabel(rb.getString("number of days ago"));


		dashTab.setText(rb.getString("dashboard"));
		repTab.setText(rb.getString("report"));
		statTab.setText(rb.getString("statistics"));
		settingsTab.setText(rb.getString("settings"));
	}

	public void selGraph(ActionEvent actionEvent){
	    reportTable.setVisible(false);
	   	lineGraph.setVisible(true);
	}
	public void selTable(ActionEvent actionEvent){
		reportTable.setVisible(true);
		lineGraph.setVisible(false);
	}

	public void showFullTableRow(MouseEvent event){
		if (event.getButton().equals(MouseButton.PRIMARY) && event.getClickCount() >= 2) {
			Meal meal = reportTable.getSelectionModel().getSelectedItem();
			BorderPane borderPane = new BorderPane();
			TextArea textArea = new TextArea();
			for(var v: meal.getFoodSets()){
				for(var f: v.getIngredients()){
					textArea.appendText(f.getName()+"\n");
				}
			}
			textArea.setEditable(false);
			textArea.setWrapText(true);
			Label label = new Label(meal.getHumanFormattedDateTime());
			borderPane.setTop(label);
			borderPane.setCenter(textArea);
			borderPane.setPadding(new Insets(10,10,10,10));
			Stage stage = new Stage();
			stage.setTitle("Full View");
			stage.setScene(new Scene(borderPane, 500, 500));
			stage.showAndWait();
		}
	}

	public String generateRating(double score,double goal,NutrientType.Type nt){
		if (nt == NutrientType.Type.CHOLESTEROL || nt == NutrientType.Type.SUGAR){
			if (score<=0.8*goal)
				return rb.getString("good job");
			else if (score<=goal)
				return rb.getString("decent");
			else
				return rb.getString("you could do better");
		}
		double p = Math.abs(score-goal)/goal*100;
		if(p<=5){
			return rb.getString("good job");
		} else if (p <= 25){
			return rb.getString("nice");
		} else if (p<=50){
			return rb.getString("decent");
		} else if (p <= 75)
			return rb.getString("not half bad");
		else
			return rb.getString("you could do better");
	}



	public void quickAddMeal(ActionEvent actionEvent) throws IOException{
			Stage menu = new Stage();
			Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("View/AddFood.fxml"));
			menu.setTitle(rb.getString("quick add meal"));
			menu.initModality(Modality.APPLICATION_MODAL);
			menu.getIcons().add(new Image("file:src/DataFiles/cheese.png"));
			menu.setScene(new Scene(root, 880, 640));
			menu.showAndWait();
			generateReportTable(LocalDate.MIN,LocalDate.MAX);
	}

	public void handleFromPicker(ActionEvent actionEvent){
		if (toPicker.getValue()!=null){
			generateReportTable(fromPicker.getValue(),toPicker.getValue());
		}
		toPicker.setDisable(false);
	}
	public void handleToPicker(ActionEvent actionEvent){
		try{
			generateReportTable(fromPicker.getValue(),toPicker.getValue());
		} catch(NullPointerException ex){
			new Alert(Alert.AlertType.WARNING,rb.getString("please select date")).showAndWait();
		}
	}

	public void initReportTable(){
		LocalDate from = LocalDate.MIN, to = LocalDate.MAX;
		reportData.clear();
//		MealData.setMeals(MealData.readMeals());
		ArrayList<Meal> meals = MealData.getMeals();
		Collections.sort(meals);
		LocalDateTime start = LocalDateTime.of(from,LocalTime.MIN), end = LocalDateTime.of(to,LocalTime.MAX);

		// binary search to find earliest meal such it occurred after LocalDateTime start
		int s=0,e=meals.size()-1,max_ind=0;
		while(s < e){
			int mid = (s+e)/2;
			if (meals.get(mid).getDateTime().isBefore(start)){
				s = mid+1;
			} else{
				max_ind = Math.max(max_ind,mid);
				e = mid;
			}
		}
		for(int i = max_ind; i <meals.size(); ++i){
			LocalDateTime ldt = meals.get(i).getDateTime();
			if (ldt.isAfter(end))
				break;
			reportData.add(meals.get(i));
		}
		reportTable.setItems(reportData);
	}

	public void generateReportTable(LocalDate from,LocalDate to){
		reportData.clear();
		MealData.setMeals(MealData.readMeals());
		if (MealData.getMeals().isEmpty())
			return;
		ArrayList<Meal> meals = MealData.getMeals();
		Collections.sort(meals);
		LocalDateTime start = LocalDateTime.of(from,LocalTime.MIN), end = LocalDateTime.of(to,LocalTime.MAX);

		// binary search to find earliest meal such it occurred after LocalDateTime start
		int s=0,e=meals.size()-1,min_ind=meals.size()+5;
//		System.out.println(meals.get(e).getDateTime().isBefore(start));
		while(s <= e){
//			System.out.println(s + " " + e);
			int mid = (s+e)/2;
			if (meals.get(mid).getDateTime().isBefore(start)){
//				System.out.println("before");
				s = mid+1;
			} else{
				min_ind = Math.min(min_ind,mid);
				e = mid-1;
			}
		}
//		System.out.println(min_ind);
		for(int i = min_ind; i <meals.size(); ++i){
			LocalDateTime ldt = meals.get(i).getDateTime();
			if (ldt.isAfter(end))
				break;
			reportData.add(meals.get(i));
		}
		reportTable.setItems(reportData);
	}

	public void generateGraph(NutrientType nt){
		LocalDateTime now = LocalDateTime.now();
		XYChart.Series series = new XYChart.Series();
		TreeMap<Integer,Double> mp = new TreeMap<Integer, Double>();
		TreeSet<Integer>  set = new TreeSet<>();
	    for(int i = 0; i < reportData.size(); ++i){
	        double amt = 0;
	        var fs = reportData.get(i).getFoodSets();
	    	for (var v: fs) {
	    		amt += NutrientType.amountFromType(v.getNutrients(),nt.getType());
			}
//	    	System.out.println(amt);
	    	int key = (int) DAYS.between(reportData.get(i).getDateTime(),now);
	    	set.add(key);
	    	mp.put(key,mp.getOrDefault(key,(double)0)+amt);
		}
	    if (set.size()<=1){
	    	graphInfoLbl.setText(rb.getString("The graph feature need more datapoints"));
	    	return;
	    } else
	    	graphInfoLbl.setText("");
	    lineGraph.getData().clear();
	    for(var v: set){
//	    	System.out.println(v);
	    	series.getData().add(new XYChart.Data<Integer,Double>(v,mp.get(v)));
	    }
		lineGraph.getData().add(series);
	}

	public void selNutrientType(ActionEvent actionEvent){
		if (!nutrientCombo.getValue().equals("") && reportData.size() != 0){
			NutrientType nt = new NutrientType(NutrientType.nameToType(NutrientType.tamilToEnglish(nutrientCombo.getValue())));
			reportUnits1.setText(nt.getUnit_name().toLowerCase());
			reportUnits2.setText(nt.getUnit_name().toLowerCase());
			double sum=0;
			for(int i = 0; i < reportData.size(); ++i){
				for (var fs: reportData.get(i).getFoodSets()){
					sum += NutrientType.amountFromType(fs.getNutrients(),nt.getType());
				}
			}
			int avg = (int) (sum/(DAYS.between(reportData.get(0).getDateTime(),reportData.get(reportData.size()-1).getDateTime())+1));
			dailyIntakeText.setText(avg + "");

			double opt = NutrientType.getOptimal(nt.getType(),userInfo);
			optimalIntakeText.setText((nt.getType()== NutrientType.Type.CHOLESTEROL|| nt.getType()== NutrientType.Type.SUGAR ? "< ":"")
					+ String.format("%.2f",opt)+"");
			generateGraph(nt);
			ratingText.setText(generateRating(avg,opt,nt.getType()));
		}
	}

//	public void stopGeneratingStats(){
//		playStats=false;
//	}
	public void generateInfoBox(){
		if (!statFlowPane.getChildren().isEmpty())
			return;
		Thread t=new Thread(new Runnable() {
			@Override
			public void run() {
				Platform.runLater(new Runnable() {
					@Override
					public void run() {
						Timeline timeline = new Timeline(
								new KeyFrame(Duration.seconds(5), new EventHandler<ActionEvent>() {
									@Override
									public void handle(ActionEvent event) {
//										System.out.println("generated");
										InfoBox infoBox = new InfoBox();
										infoBox.randomiseInfoBox();
										if (infoBox.fillInfoBox() != -1) {
//											System.out.println("gen");
											statFlowPane.getChildren().add(infoBox);
										}
//											System.out.println("aborted");
									}
								})
						);
						timeline.setCycleCount(20);
						timeline.play();
					}
				});
			}
		});
		ExecutorService executor = Executors.newCachedThreadPool();
		executor.submit(t);
		executor.shutdown();
	}
	public static boolean isInitialised(){
		return initialised;
	}
	// settings
	public void changeUserSettings(ActionEvent actionEvent){
		userInfo.getUserInfo();
	}

	public static Locale getTamilLocale() {
		return tamilLocale;
	}

	public static void setTamilLocale(Locale tamilLocale) {
		ApplicationController.tamilLocale = tamilLocale;
	}

	public static Locale getEnglishLocale() {
		return englishLocale;
	}

	public static void setEnglishLocale(Locale englishLocale) {
		ApplicationController.englishLocale = englishLocale;
	}

	public static ResourceBundle getTl() {
		return tl;
	}

	public static void setTl(ResourceBundle tl) {
		ApplicationController.tl = tl;
	}

	public static ResourceBundle getEn() {
		return en;
	}

	public static void setEn(ResourceBundle en) {
		ApplicationController.en = en;
	}

	public static Locale getUserLocale() {
		return userLocale;
	}

	public static void setUserLocale(Locale userLocale) {
		ApplicationController.userLocale = userLocale;
	}

	public static ResourceBundle getRb() {
		return rb;
	}

	public static void setRb(ResourceBundle rb) {
		ApplicationController.rb = rb;
	}
}
