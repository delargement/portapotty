package Controller;

import Model.FoodData;
import Model.FoodItem;
import Model.FoodSet;
import View.AddFoodMenu;
import View.FoodBox;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.util.ArrayList;

public class AddPresetController extends AddFoodMenuController {

	@FXML
	private HBox                        selBox;
	@FXML
	private TextField                   searchBar;
	@FXML
	private TableView<String>           foodSettable;
	@FXML
	private TableColumn<String, String> foodCol;
	@FXML
	private RadioButton                 keywordsRadio;
	@FXML
	private RadioButton                 regexRadio;
	@FXML
	private TextField                   nameField;
	@FXML
	private Button doneBtn;

	@Override
	public void handleDone(ActionEvent actionEvent) {
		if (selBox.getChildren().isEmpty()){
			new Alert(Alert.AlertType.CONFIRMATION,"Nothing selected").showAndWait();
			return;
		}
		if (nameField.getText().equals("")){
			new Alert(Alert.AlertType.WARNING,"Please enter the name of the preset").showAndWait();
			return;
		}
		ArrayList<FoodItem> fi = new ArrayList<>();
		for(var v: selBox.getChildren()){
			FoodItem f = (FoodItem) ((FoodBox) v).getFood();
			fi.add(new FoodItem(f.getName(),f.getId(),f.getNutrients()));
		}
		FoodSet fs = new FoodSet(nameField.getText(),fi);
		FoodData.getPresets().add(fs);
		FoodData.appendWritePresets(fs);
		((Stage) doneBtn.getScene().getWindow()).close();
	}
}
