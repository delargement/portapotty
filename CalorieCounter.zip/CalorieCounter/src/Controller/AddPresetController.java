package Controller;

import Model.FoodData;
import Model.FoodItem;
import Model.FoodSet;
import View.AddFoodMenu;
import View.FoodBox;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class AddPresetController extends AddFoodMenuController implements Initializable{

	@FXML
	private HBox                        selBox;
	@FXML
	private TextField                   searchBar;
	@FXML
	private TableView<String>           foodSettable;
	@FXML
	private TableColumn<String, String> foodCol;
	@FXML
	private RadioButton                 keywordsRadio;
	@FXML
	private RadioButton                 regexRadio;
	@FXML
	private TextField                   nameField;
	@FXML
	private Button doneBtn;
//	@FXML
//	private Tab menuTab;
//
//	private ResourceBundle rb = ApplicationController.getRb();
//
//	public void initialize(URL location, ResourceBundle resources) {
//		data.addAll(FoodData.fetchFoodList());
//		foodCol.setCellValueFactory(s -> new SimpleStringProperty(s.getValue()));
//		foodSettable.setItems(data);
//
//
//		foodCol.setText(rb.getString("food"));
//
//	}


	@Override
	public void handleDone(ActionEvent actionEvent) {
//		System.out.println("gw");
		if (selBox.getChildren().isEmpty()){
			new Alert(Alert.AlertType.WARNING,ApplicationController.getRb().getString("nothing selected")).showAndWait();
			return;
		}
		if (nameField.getText().equals("")){
			new Alert(Alert.AlertType.WARNING,ApplicationController.getRb().getString("please enter the name of the preset")).showAndWait();
			return;
		}
		if (nameField.getText().contains(",")){
			new Alert(Alert.AlertType.WARNING,ApplicationController.getRb().getString("invalid input")).showAndWait();
		}
		for(var v: FoodData.getPresets()){
			if (v.getName().equals(nameField.getText())){
				new Alert(Alert.AlertType.ERROR,ApplicationController.getRb().getString("a preset with that name already exists")).showAndWait();
				return;
			}
		}
		ArrayList<FoodItem> fi = new ArrayList<>();
		for(var v: selBox.getChildren()){
			FoodItem f = (FoodItem) (((FoodBox) v).getFood());
			fi.add(new FoodItem(f.getName(),f.getId(),f.getNutrients()));
		}
		FoodSet fs = new FoodSet(nameField.getText(),fi);
		FoodData.getPresets().add(fs);
		FoodData.appendWritePresets(fs);
		((Stage) doneBtn.getScene().getWindow()).close();
	}
}
