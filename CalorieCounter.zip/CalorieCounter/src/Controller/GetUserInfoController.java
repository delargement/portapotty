package Controller;

import Model.UserInfo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class GetUserInfoController implements Initializable {
	@FXML
	private Button doneBtn;

	@FXML
	private ComboBox<String> genderBox;

	@FXML
	private ComboBox<String> lifestyleBox;

	@FXML
	private TextField ageField;

	@FXML
	private TextField weightField;

	private ResourceBundle rb = ApplicationController.getRb();
	private ObservableList<String> gender = FXCollections.observableArrayList(rb.getString("male"),rb.getString("female"));
	private ObservableList<String> lifestyles = FXCollections.observableArrayList(rb.getString("sedentary"),rb.getString("moderate"),rb.getString("active"));

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		genderBox.setItems(gender);
		genderBox.getSelectionModel().selectFirst();
		lifestyleBox.setItems(lifestyles);
		lifestyleBox.getSelectionModel().selectFirst();
	}

	public void handleDone(ActionEvent actionEvent){
		String genderInp = genderBox.getValue();
		int gender,lifestyle,age,weight;
		Alert invInp = new Alert(Alert.AlertType.WARNING,rb.getString("invalid input"));
		if (genderInp.equals(rb.getString("male"))){
			gender = UserInfo.MALE;
		} else if (genderInp.equals(rb.getString("female"))){
			gender = UserInfo.FEMALE;
		} else{
			invInp.showAndWait();
			return;
		}
		String lifestyleInp = lifestyleBox.getValue();
		if (lifestyleInp.equals(rb.getString("sedentary"))){
			lifestyle=UserInfo.SEDENTARY;
		} else if (lifestyleInp.equals(rb.getString("moderate"))){
			lifestyle= UserInfo.MODERATE;
		} else if (lifestyleInp.equals(rb.getString("active"))){
			lifestyle=UserInfo.ACTIVE;
		}else{
			invInp.showAndWait();
			return;
		}
		try{
			age = Integer.parseInt(ageField.getText());
			if (age <=0 || age >= 200) {
				invInp.showAndWait();
				return;
			}
		} catch (NumberFormatException ex){
			invInp.showAndWait();
			return;
		}
		try{
			weight=Integer.parseInt(weightField.getText());
			if (weight <=0) {
				invInp.showAndWait();
				return;
			}
		} catch (NumberFormatException ex) {
			invInp.showAndWait();
			return;
		}
		UserInfo info = new UserInfo(age,gender,lifestyle,weight);
		info.writeInfo();
		((Stage) doneBtn.getScene().getWindow()).close();
		return;
	}
}
