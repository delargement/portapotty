package Controller;

import Model.FoodData;
import Model.FoodItem;
import Model.Nutrients;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class CreateFoodController {
	@FXML
	private TextField nameField;
	@FXML
	private TextField proteinField;
	@FXML
	private TextField energyField;
	@FXML
	private TextField carbohydratesField;
	@FXML
	private TextField fiberField;
	@FXML
	private TextField sugarsField;
	@FXML
	private TextField cholesterolField;
	@FXML
	private Button    doneBtn;

	public void handleDone(ActionEvent actionEvent){
		if (nameField.getText().equals("")) {
			new Alert(Alert.AlertType.WARNING, "Please input name.").showAndWait();
			return;
		}try{
			String name = nameField.getText();
			double pr = Double.parseDouble(proteinField.getText()), en = Double.parseDouble(energyField.getText()),
					ca = Double.parseDouble(carbohydratesField.getText()), fi = Double.parseDouble(fiberField.getText()),
					su = Double.parseDouble(sugarsField.getText()), ch = Double.parseDouble(cholesterolField.getText());
			FoodItem foodItem = new FoodItem(name, ""+FoodData.readAndUpdateFoodCount(),new Nutrients(
					pr,en,ca,fi,su,ch
			));
			FoodData.writeFood(foodItem);
		} catch (NumberFormatException ex){
			new Alert(Alert.AlertType.WARNING,"Invalid input").showAndWait();
		}
	}
}
