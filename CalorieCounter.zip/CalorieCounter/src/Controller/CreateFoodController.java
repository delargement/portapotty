package Controller;

import Model.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class CreateFoodController implements Initializable {
	@FXML
	private TextField nameField;
	@FXML
	private TextField proteinField;
	@FXML
	private TextField energyField;
	@FXML
	private TextField carbohydratesField;
	@FXML
	private TextField fiberField;
	@FXML
	private TextField sugarsField;
	@FXML
	private TextField cholesterolField;
	@FXML
	private Button doneBtn;
	@FXML
	private Label  name;

	@FXML
	private Label protein;

	@FXML
	private Label energy;

	@FXML
	private Label carbo;

	@FXML
	private Label fiber;

	@FXML
	private Label sugar;

	@FXML
	private Label chol;


	@FXML
	private TableView<DataEntry> createFoodTable;

	@FXML
	private TableColumn<DataEntry, String> nameCol;

	@FXML
	private TableColumn<DataEntry, Double> energyCol;

	@FXML
	private TableColumn<DataEntry,Double> proteinCol;

	@FXML
	private TableColumn<DataEntry, Double> carbohydratesCol;

	@FXML
	private TableColumn<DataEntry, Double> sugarCol;

	@FXML
	private TableColumn<DataEntry, Double> fiberCol;

	@FXML
	private TableColumn<DataEntry, Double> cholesterolCol;
	@FXML
	private Button                             loadTableBtn;


	private	ResourceBundle rb = ApplicationController.getRb();


	ObservableList<DataEntry> data = FXCollections.observableArrayList();

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		name.setText(rb.getString("name"));
		protein.setText(rb.getString("protein"));
		carbo.setText(rb.getString("carbohydrates"));
		energy.setText(rb.getString("energy"));
		fiber.setText(rb.getString("fiber"));
		sugar.setText(rb.getString("sugar"));
		chol.setText(rb.getString("cholesterol"));

		nameCol.setText(rb.getString("name"));
		energyCol.setText(rb.getString("energy")+"(kcal)");
		proteinCol.setText(rb.getString("protein")+"(g)");
		carbohydratesCol.setText(rb.getString("carbohydrates")+"(g)");
		sugarCol.setText(rb.getString("sugar")+"(g)");
		fiberCol.setText(rb.getString("fiber")+"(g)");
		cholesterolCol.setText(rb.getString("cholesterol")+"(mg)");

		nameCol.setCellValueFactory(new PropertyValueFactory<DataEntry,String>("name"));
		energyCol.setCellValueFactory(new PropertyValueFactory<DataEntry,Double>("energy"));
		proteinCol.setCellValueFactory(new PropertyValueFactory<DataEntry,Double>("protein"));
		carbohydratesCol.setCellValueFactory(new PropertyValueFactory<DataEntry,Double>("carbohydrates"));
		sugarCol.setCellValueFactory(new PropertyValueFactory<DataEntry,Double>("sugars"));
		fiberCol.setCellValueFactory(new PropertyValueFactory<DataEntry,Double>("fiber"));
		cholesterolCol.setCellValueFactory(new PropertyValueFactory<DataEntry,Double>("cholesterol"));
		carbohydratesCol.setCellValueFactory(new PropertyValueFactory<DataEntry,Double>("energy"));
	}

	public void loadTable(ActionEvent actionEvent){
		data.clear();
		MyFoodDatabase.readData();
		data.addAll(MyFoodDatabase.getData());
		createFoodTable.setItems(data);
	}

	public void addToFields(MouseEvent event) {
		if (event.getButton().equals(MouseButton.PRIMARY) && event.getClickCount() >= 2) {
			DataEntry dataEntry = createFoodTable.getSelectionModel().getSelectedItem();
			nameField.setText(dataEntry.getName());
			if (!DataEntry.isDataNull(dataEntry.getCarbohydrates()))
				carbohydratesField.setText(dataEntry.getCarbohydrates() + "");
			if (!DataEntry.isDataNull(dataEntry.getCholesterol()))
				cholesterolField.setText(dataEntry.getCholesterol() + "");
			if (!DataEntry.isDataNull(dataEntry.getEnergy()))
				energyField.setText(dataEntry.getEnergy() + "");
			if (!DataEntry.isDataNull(dataEntry.getSugars()))
				sugarsField.setText(dataEntry.getSugars() + "");
			if (!DataEntry.isDataNull(dataEntry.getFiber()))
				fiberField.setText(dataEntry.getFiber() + "");
			if (!DataEntry.isDataNull(dataEntry.getProtein()))
				proteinField.setText(dataEntry.getProtein() + "");
		}
	}


	public void handleDone(ActionEvent actionEvent){
		if (nameField.getText().equals("")) {
			new Alert(Alert.AlertType.WARNING, ApplicationController.getRb().getString("please input name")).showAndWait();
			return;
		}try{
			String name = nameField.getText();
			double pr = Double.parseDouble(proteinField.getText()), en = Double.parseDouble(energyField.getText()),
					ca = Double.parseDouble(carbohydratesField.getText()), fi = Double.parseDouble(fiberField.getText()),
					su = Double.parseDouble(sugarsField.getText()), ch = Double.parseDouble(cholesterolField.getText());
			FoodItem foodItem = new FoodItem(name, ""+FoodData.readAndUpdateFoodCount(),new Nutrients(
					pr,en,ca,fi,su,ch
			));
//			System.out.println(foodItem);
			FoodData.writeFood(foodItem);
			((Stage) doneBtn.getScene().getWindow()).close();
		} catch (NumberFormatException ex){
			new Alert(Alert.AlertType.WARNING,ApplicationController.getRb().getString("invalid input")).showAndWait();
		}
	}


}
