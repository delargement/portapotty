package Controller;

import Model.*;
import View.UserInfo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.ResourceBundle;

public class applicationController implements Initializable {
	@FXML
	private TableView<Meal> reportTable;

	@FXML
	private TableColumn<Meal,String> reportDateCol;

	@FXML
	private TableColumn<Meal,String> reportMealCol;

	@FXML
	private DatePicker fromPicker;

	@FXML
	private DatePicker toPicker;

	@FXML
	private ComboBox<String> nutrientCombo;

	@FXML
	private Label ratingText;

	@FXML
	private Label dailyIntakeText;

	@FXML
	private Label reportUnits1;

	@FXML
	private Label optimalIntakeText;

	@FXML
	private Label reportUnits2;

	@FXML
	private Button quickAddMealBtn;

	ObservableList<Meal>   reportData = FXCollections.observableArrayList();
	ObservableList<String> nutrientTypes = FXCollections.observableArrayList(
			"protein","energy","carbohydrates","fiber","sugar","cholesterol"
	);
	UserInfo               userInfo;


	public void initialize(URL location, ResourceBundle resources) {
		reportDateCol.setCellValueFactory(new PropertyValueFactory<Meal,String>("formattedDateTime"));
		reportMealCol.setCellValueFactory(new PropertyValueFactory<Meal,String>("formattedDateTime"));
		generateReportTable(LocalDate.MIN,LocalDate.MAX);
		nutrientCombo.setItems(nutrientTypes);
		userInfo = new UserInfo();
	}

	public void quickAddMeal(ActionEvent actionEvent){
		try {
			Stage menu = new Stage();
			Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("View/AddFood.fxml"));
			menu.setTitle("Hello World");
			menu.setScene(new Scene(root, 880, 640));
			menu.show();
		} catch (IOException ex){
			new Alert(Alert.AlertType.ERROR,"addfood.fxml not found").showAndWait();
		}
	}

	public void handleFromPicker(ActionEvent actionEvent){
		toPicker.setDisable(false);
	}
	public void handleToPicker(ActionEvent actionEvent){
		try{
			generateReportTable(fromPicker.getValue(),toPicker.getValue());
		} catch(NullPointerException ex){
			new Alert(Alert.AlertType.WARNING,"Please select date").showAndWait();
		}
	}
	public void generateReportTable(LocalDate from,LocalDate to){
		reportData.clear();
		ArrayList<Meal> meals = MealData.getMeals();
		Collections.sort(meals);
		LocalDateTime start = LocalDateTime.of(from,LocalTime.MIN), end = LocalDateTime.of(to,LocalTime.MAX);

		// binary search to find earliest meal such it occurred after LocalDateTime start - O(lgn)
		int s=0,e=meals.size()-1,max_ind=0;
		while(s < e){
			int mid = (s+e)/2;
			if (meals.get(mid).getDateTime().isBefore(start)){
				s = mid+1;
			} else{
				max_ind = Math.max(max_ind,mid);
				e = mid;
			}
		}
		for(int i = max_ind; i <meals.size(); ++i){
			LocalDateTime ldt = meals.get(i).getDateTime();
			if (ldt.isAfter(end))
				break;
			reportData.add(meals.get(i));
		}
		reportTable.setItems(reportData);
	}
	public void selNutrientType(ActionEvent actionEvent){
		if (!nutrientCombo.getValue().equals("") && reportData.size() != 0){
			NutrientType nt = new NutrientType(NutrientType.nameToType(nutrientCombo.getValue()));
			reportUnits1.setText(nt.getUnit_name());
			reportUnits2.setText(nt.getUnit_name());
			double sum=0;
			for(int i = 0; i < reportData.size(); ++i){
				for (var fs: reportData.get(i).getFoodSets()){
					sum += NutrientType.amountFromType(fs.getNutrients(),nt.getType());
				}
			}
			int avg = (int) sum/reportData.size();
			dailyIntakeText.setText(avg + "");

			optimalIntakeText.setText((nt.getType()== NutrientType.Type.CARBOHYDRATES || nt.getType()== NutrientType.Type.SUGAR ? "<":"")
					+ NutrientType.getOptimal(nt.getType(),userInfo)+"");
		}
	}


}
