package Model;

import javafx.scene.control.Alert;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class MealData {
	private static ArrayList<Meal> meals = new ArrayList<>();
	private static final String MEALFILE = "src/DataFiles/meal_list.csv";

	public static void writeMeals(boolean append){
		try{
			PrintWriter pw = new PrintWriter(new FileOutputStream(MEALFILE,append));
			for(Meal m : meals){
				pw.println(m.getDateTime() + "," + m.getFormattedFoodSets());
			}
			pw.close();
		} catch(FileNotFoundException ex){
			new Alert(Alert.AlertType.ERROR,MEALFILE + " not found.").showAndWait();
		}
	}

	public static ArrayList<Meal> readMeals(){
		ArrayList<Meal> meals = new ArrayList<>();
		try{
			Scanner inp = new Scanner(new File(MEALFILE));
//			2020-10-03T14:16:26.440906500,minerals chicken skin raw from drumsticks and thighs non-enhanced (co1ct1in1) - 14b-01-03-min
			inp.nextLine();
			while(inp.hasNext()) {

				String[] tok = inp.nextLine().split(",");
				LocalDateTime ldt = LocalDateTime.parse(tok[0]);
				ArrayList<FoodItem> foodItemsList = new ArrayList<>();
				for (int i = 1; i < tok.length; ++i) {
					String s = tok[i], id = FoodData.foodNameToId(s);
					foodItemsList.add(new FoodItem(s, id, FoodData.fetchFoodData(id)));
				}
				FoodSet fs = new FoodSet("", foodItemsList);
				ArrayList<FoodSet> tmp = new ArrayList<>();
				tmp.add(fs);
				meals.add(new Meal(ldt, tmp));
			}
			inp.close();
		} catch(FileNotFoundException ex){

			new Alert(Alert.AlertType.ERROR,MEALFILE + " not found").showAndWait();
		}
		return meals;
	}

	public static ArrayList<Meal> getMeals() {
		return meals;
	}

	public static void setMeals(ArrayList<Meal> meals) {
		MealData.meals = meals;
	}
}
