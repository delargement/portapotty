package Model;

import Controller.ApplicationController;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.FileAlreadyExistsException;
import java.util.ArrayList;
import java.util.Scanner;

public class MyFoodDatabase {
	private static final String FILE = "src/DataFiles/myFoodData.csv";
	private static ArrayList<DataEntry> data = new ArrayList<>();

//	Name,Calories,Protein (g),Carbohydrate (g),Sugars (g),Fiber (g),Cholesterol (mg)
	public static void readData(){
		try {
			Scanner inp = new Scanner(new File(FILE));
			inp.nextLine();
			data.clear();
			while(inp.hasNext()){
				String[] tok = inp.nextLine().split(",");
				Double cal= Double.parseDouble(tok[1]),pro=Double.parseDouble(tok[2]),carb=Double.parseDouble(tok[3]),
						sug=Double.parseDouble(tok[4]),fib=Double.parseDouble(tok[5]),chol=Double.parseDouble(tok[4]);
				DataEntry de = new DataEntry(tok[0],cal,pro,carb,sug,fib,chol);
				data.add(de);
			}
			inp.close();
		} catch (FileNotFoundException ex){
			new Alert(Alert.AlertType.ERROR,FILE + " " + ApplicationController.getRb().getString("not found")).showAndWait();
		}
	}

	public static ArrayList<DataEntry> getData() {
		return data;
	}

	public static void setData(ArrayList<DataEntry> data) {
		MyFoodDatabase.data = data;
	}
}
