package Model;

public class DataEntry {

//	Name,Calories,Protein (g),Carbohydrate (g),Sugars (g),Fiber (g),Cholesterol (mg)
	private String name;
	private	double energy,protein,carbohydrates,sugars,fiber,cholesterol;

	public DataEntry(String name, double calories, double protein, double carbohydrates, double sugars, double fiber, double cholesterol) {
		this.name = name;
		this.energy = calories;
		this.protein = protein;
		this.carbohydrates = carbohydrates;
		this.sugars = sugars;
		this.fiber = fiber;
		this.cholesterol = cholesterol;
	}

	public static boolean isDataNull(double a){
		return Math.abs(a-(-1)) <= 1e-6;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getEnergy() {
		return energy;
	}

	public void setEnergy(double energy) {
		this.energy = energy;
	}

	public double getProtein() {
		return protein;
	}

	public void setProtein(double protein) {
		this.protein = protein;
	}

	public double getCarbohydrates() {
		return carbohydrates;
	}

	public void setCarbohydrates(double carbohydrates) {
		this.carbohydrates = carbohydrates;
	}

	public double getSugars() {
		return sugars;
	}

	public void setSugars(double sugars) {
		this.sugars = sugars;
	}

	public double getFiber() {
		return fiber;
	}

	public void setFiber(double fiber) {
		this.fiber = fiber;
	}

	public double getCholesterol() {
		return cholesterol;
	}

	public void setCholesterol(double cholesterol) {
		this.cholesterol = cholesterol;
	}
}
