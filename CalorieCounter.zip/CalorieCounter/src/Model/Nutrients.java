package Model;

public class Nutrients {
	private double protein, energy,carbohydrates,fiber,sugar,cholesterol;
	private final String proteinID = "1003", energyId = "1008",carbohydratesId = "1050", fiberId = "1082",
			sugarId = "1235",cholesterolId = "1253";
	private static final double VOID = 0;

	public Nutrients(){
		this(VOID,VOID,VOID,VOID,VOID,VOID);
	}
	public Nutrients(double protein, double energy, double carbohydrates, double fiber, double sugar, double cholestrol) {
		this.protein = protein;
		this.energy = energy;
		this.carbohydrates = carbohydrates;
		this.fiber = fiber;
		this.sugar = sugar;
		this.cholesterol = cholestrol;
	}

	public void addNutrients(Nutrients nut){
		this.setEnergy(energy +nut.getEnergy());
		this.setCarbohydrates(carbohydrates+nut.getCarbohydrates());
		this.setCholesterol(cholesterol+nut.getCholesterol());
		this.setFiber(fiber+nut.getFiber());
		this.setProtein(protein+nut.getProtein());
		this.setSugar(sugar+nut.getSugar());
	}

	public void addNutrients(NutrientType nut, double amt){
		switch (nut.getType()){
			case ENERGY:
				setEnergy(energy +amt);
				break;
			case CARBOHYDRATES:
				setCarbohydrates(carbohydrates+amt);
				break;
			case CHOLESTEROL:
				setCholesterol(cholesterol+amt);
				break;
			case SUGAR:
				setSugar(sugar+amt);
				break;
			case FIBER:
				setFiber(fiber+amt);
				break;
			case PROTEIN:
				setProtein(protein+amt);
				break;
		}
	}

	@Override
	public String toString() {
		return protein + "," + energy + "," + carbohydrates + "," + fiber + "," + sugar + "," + cholesterol;
	}

	public double getProtein() {
		return protein;
	}

	public void setProtein(double protein) {
		this.protein = protein;
	}

	public double getEnergy() {
		return energy;
	}

	public void setEnergy(double energy) {
		this.energy = energy;
	}

	public double getCarbohydrates() {
		return carbohydrates;
	}

	public void setCarbohydrates(double carbohydrates) {
		this.carbohydrates = carbohydrates;
	}

	public double getFiber() {
		return fiber;
	}

	public void setFiber(double fiber) {
		this.fiber = fiber;
	}

	public double getSugar() {
		return sugar;
	}

	public void setSugar(double sugar) {
		this.sugar = sugar;
	}

	public double getCholesterol() {
		return cholesterol;
	}

	public void setCholesterol(double cholesterol) {
		this.cholesterol = cholesterol;
	}
}
