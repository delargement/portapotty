package Model;

import java.util.ArrayList;

public class FoodItem extends Food {
	private String id;
	public FoodItem(String name,String id,Nutrients nutrients){
		super(name,nutrients);
		this.id = id;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public static Nutrients calcNutrients(ArrayList<FoodItem> foodSets)	{
		Nutrients nt = new Nutrients();
		for (var v: foodSets){
			nt.addNutrients(v.getNutrients());
		}
		return nt;
	}

}
