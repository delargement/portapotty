package Model;

public class FoodItem extends Food {
	private String id;
	public FoodItem(String name,String id,Nutrients nutrients){
		super(name,nutrients);
		this.id = id;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
}
