package Model;

import javafx.scene.control.Alert;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class FoodData {
	private static final String NUTRIENTFILE = "src/DataFiles/nutrient.csv", FOODNUTFILE = "src/DataFiles/food_nutrient.csv",FOODFILE = "src/DataFiles/food.csv",FOODLIST = "src/DataFiles/foodList.txt",
			PRESETFILE = "src/DataFiles/presets.csv", FOODID = "src/DataFiles/foodIdRunningNo.txt";
	private static ArrayList<FoodSet> presets = new ArrayList<>();
	public FoodData(){}

	public static ArrayList<String> fetchFoodList(){
		ArrayList<String> list = new ArrayList<>();
		try{
			Scanner inp = new Scanner(new File(FOODLIST));
			boolean skip =true;
			while(inp.hasNext()) {
				if (skip){
					skip=false;
					inp.nextLine();
					continue;
				}
				list.add(inp.nextLine().toLowerCase());
			}
		} catch (FileNotFoundException ex){
			ex.printStackTrace();
			new Alert(Alert.AlertType.ERROR,FOODLIST + " not found").showAndWait();
		}
		return list;
	}

	public static Nutrients fetchFoodData(String id){
		Nutrients nut = new Nutrients();
		ArrayList<String[]> list = findLine(1,id,FOODNUTFILE,false);
		for(var arr: list){
			if (!Arrays.asList(NutrientType.getIds()).contains(arr[2]))
				continue;
			NutrientType nutType = new NutrientType(arr[2]);
			nut.addNutrients(nutType,Double.parseDouble(arr[3]));
		}
		return nut;
	}


	public static String foodNameToId(String name){
//		System.out.println(name);
		ArrayList<String[]> list = findLine(2,name,FOODFILE,true);
		return list.get(0)[0];
	}

	public static ArrayList<String[]> findLine(int idx,String key,String file){
		return findLine(idx, key, file,false);
	}
	public static ArrayList<String[]> findLine(int idx,String key,String file,boolean once){
//		System.out.println(key);
		ArrayList<String[]> list = new ArrayList<>();
		Scanner inp;
		try {
			inp = new Scanner(new File(file));
			inp.nextLine();
			while(inp.hasNext()){

				String s = inp.nextLine().toLowerCase();
				String tok[]=s.split("[,]");
//				System.out.println(tok[idx]);
//				System.out.println(tok[idx] + " " + key.trim() + tok[idx].compareTo(key));

				if (tok[idx].equals(key)){
//					System.out.println("true");
					list.add(tok);
					if (once) {
						inp.close();
						return list;
					}
				}
			}
			inp.close();
		} catch(FileNotFoundException ex){
			new Alert(Alert.AlertType.ERROR,file + " not found").show();
		}
		return list;
	}


	public static ArrayList<FoodSet> readPresets(){
		ArrayList<FoodSet> foodSets = new ArrayList<>();
		try {
			Scanner inp = new Scanner(new File(PRESETFILE));
			inp.nextLine();
			while(inp.hasNext()){
				String tok[] = inp.nextLine().split("[,]");
//				System.out.println(tok.length);
				ArrayList<FoodItem> ingred = new ArrayList<>();
				for(int i = 1; i < tok.length-1;++i){
					String id = foodNameToId(tok[i]);
					ingred.add(new FoodItem(tok[i],id,fetchFoodData(id)));
				}
				foodSets.add(new FoodSet(tok[0],ingred));
			}
			inp.close();
		} catch (FileNotFoundException ex){
			new Alert(Alert.AlertType.ERROR,PRESETFILE + " not found").show();
		}
		return foodSets;
	}

	public static void writePresets(){
		try{
			PrintWriter pw = new PrintWriter(new File(PRESETFILE));
			for(var v: presets){
				pw.println(v);
			}
			pw.close();
		} catch(FileNotFoundException ex){
			new Alert(Alert.AlertType.ERROR,PRESETFILE + " not found").show();
		}
	}
	public static void appendWritePresets(FoodSet fs){
		var a = new ArrayList<FoodSet>();
		a.add(fs);
		appendWritePresets(a);
	}
	public static void appendWritePresets(ArrayList<FoodSet> fs){
		try{
			PrintWriter pw = new PrintWriter(new FileOutputStream(new File(PRESETFILE),true));
			for (var v: fs){
//				System.out.println(v);
				pw.println(v);
			}
			pw.close();
		} catch(FileNotFoundException ex){
			new Alert(Alert.AlertType.ERROR,PRESETFILE + " not found");
		}
	}

	public static ArrayList<FoodSet> getPresets() {
		return presets;
	}

	public static void setPresets(ArrayList<FoodSet> presets) {
		FoodData.presets = presets;
	}

	public static int readFoodCount(){
		try{
			Scanner inp = new Scanner(new File(FOODID));
			int n = inp.nextInt();
			inp.close();
			return n;
		} catch(FileNotFoundException ex){
			new Alert(Alert.AlertType.ERROR,FOODID + " not found").showAndWait();
		}
		return 0;
	}
	public static void updateFoodCount(int n){
		try{
			PrintWriter pw = new PrintWriter(FOODID);
			pw.println(n);
			pw.close();
		} catch(FileNotFoundException ex){
			new Alert(Alert.AlertType.ERROR,FOODID + " not found").showAndWait();
		}
	}

	public static int readAndUpdateFoodCount(){
		int n = readFoodCount();
		updateFoodCount(n+1);
		return n;
	}

	public static void writeFood(FoodItem foodItem){
		try {
			PrintWriter pw = new PrintWriter(new FileOutputStream(FOODFILE,true));
			pw.println(foodItem.getId() + ",custom," + foodItem.getName());
			pw.close();
		}catch (FileNotFoundException ex){
			new Alert(Alert.AlertType.ERROR, FOODFILE + " not found").showAndWait();
			return;
		}
		try{
			PrintWriter pw = new PrintWriter(new FileOutputStream(FOODLIST,true));
			pw.println(foodItem.getName());
			pw.close();
		} catch(FileNotFoundException ex){
			new Alert(Alert.AlertType.ERROR,FOODLIST+" not found").showAndWait();
		}
		try {
			PrintWriter pw = new PrintWriter(new FileOutputStream(FOODNUTFILE,true));
			Nutrients nut = foodItem.getNutrients();
			Double[] amounts = {nut.getProtein(),nut.getEnergy(),nut.getCarbohydrates(),nut.getFiber(),nut.getSugar(),nut.getCholesterol()};
			NutrientType nt;
			String[] nutId  = NutrientType.getIds();
			for(int i = 0; i < amounts.length; ++i){
				pw.println(0 + "," + foodItem.getId() + "," + nutId[i] + "," + amounts[i]);
			}
			pw.close();
		}catch (FileNotFoundException ex){
			new Alert(Alert.AlertType.ERROR, FOODNUTFILE + " not found").showAndWait();
		}
	}
}
