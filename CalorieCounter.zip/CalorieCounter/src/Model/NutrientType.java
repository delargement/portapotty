package Model;

import View.UserInfo;

import java.util.Arrays;

public class NutrientType {
	private String id,unit_name;
	private              Type            type;
	private final static Type[] types = {Type.PROTEIN,Type.ENERGY,Type.CARBOHYDRATES, Type.FIBER,Type.SUGAR, Type.CHOLESTEROL};
	private final static String[] ids = {"1003","1008","1050","1082","1235","1253"},
					names = {"protein","energy","carbohydrates","fiber","sugar","cholesterol"},
					unit_names = {"g","kcal","g","g","g","mg"};
	public enum Type{
		PROTEIN,ENERGY,CARBOHYDRATES,FIBER,SUGAR,CHOLESTEROL
	}

	public NutrientType(String id, Type type, String unit_name) {
		this.id = id;
		this.type = type;
		this.unit_name = unit_name;
	}
	public NutrientType(String id){
		this(id,types[Arrays.asList(ids).indexOf(id)],unit_names[Arrays.asList(ids).indexOf(id)]);
	}
	public NutrientType(Type type){
		this(ids[Arrays.asList(types).indexOf(type)],type,unit_names[Arrays.asList(types).indexOf(type)]);
	}

	public static double getOptimal(Type type, UserInfo userInfo){
		double optimal[] = {userInfo.optimalProtein(),userInfo.optimalCalories(),userInfo.optimalCarbohydrates(),
			userInfo.optimalFiber(),userInfo.optimalSugar(),userInfo.optimalCholesterol()};
		return optimal[Arrays.asList(types).indexOf(type)];
	}

	public static double amountFromType(Nutrients nut,Type nt){
		if (nt.equals(Type.PROTEIN))
			return nut.getProtein();
		else if (nt.equals(Type.ENERGY))
			return nut.getEnergy();
		else if (nt.equals(Type.CARBOHYDRATES))
			return nut.getCarbohydrates();
		else if (nt.equals(Type.FIBER))
			return nut.getFiber();
		else if(nt.equals(Type.SUGAR))
			return nut.getSugar();
		else
			return nut.getCholesterol();
	}


	public static Type nameToType(String name){
		switch(name){
			case "protein":
				return Type.PROTEIN;
			case "energy":
				return Type.ENERGY;
			case "carbohydrates":
				return Type.CARBOHYDRATES;
			case "fiber":
				return Type.FIBER;
			case "sugar":
				return Type.SUGAR;
			case "cholesterol":
				return Type.CHOLESTEROL;
		}
		return null;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public String getUnit_name() {
		return unit_name;
	}

	public void setUnit_name(String unit_name) {
		this.unit_name = unit_name;
	}

	public static Type[] getTypes() {
		return types;
	}

	public static String[] getIds() {
		return ids;
	}

	public static String[] getNames() {
		return names;
	}

	public static String[] getUnit_names() {
		return unit_names;
	}
}
