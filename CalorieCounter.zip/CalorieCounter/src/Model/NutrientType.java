package Model;

import java.util.Arrays;

public class NutrientType {
	private String id,unit_name;
	private              Type            type;
	private final static Type[] types = {Type.PROTEIN,Type.ENERGY,Type.CARBOHYDRATES, Type.FIBER,Type.SUGAR, Type.CHOLESTEROL};
	private final static String[] ids = {"1003","1008","1050","1082","1235","1253"},
					names = {"protein","energy","carbohydrates","fiber","sugar","cholesterol"},
					unit_names = {"g","kcal","kcal","g","g","mg"};
	public enum Type{
		PROTEIN,ENERGY,CARBOHYDRATES,FIBER,SUGAR,CHOLESTEROL
	}

	public NutrientType(String id, Type type, String unit_name) {
		this.id = id;
		this.type = type;
		this.unit_name = unit_name;
	}
	public NutrientType(String id){
		this(id,types[Arrays.asList(ids).indexOf(id)],unit_names[Arrays.asList(ids).indexOf(id)]);
	}
	public NutrientType(Type type){
		this(ids[Arrays.asList(types).indexOf(type)],type,unit_names[Arrays.asList(types).indexOf(type)]);
	}

	public static double getOptimal(Type type, UserInfo userInfo){
		double optimal[] = {userInfo.optimalProtein(),userInfo.optimalCalories(),userInfo.optimalCarbohydrates(),
			userInfo.optimalFiber(),userInfo.optimalSugar(),userInfo.optimalCholesterol()};
		return optimal[Arrays.asList(types).indexOf(type)];
	}

	public static double amountFromType(Nutrients nut,Type nt){
		if (nt.equals(Type.PROTEIN))
			return nut.getProtein();
		else if (nt.equals(Type.ENERGY))
			return nut.getEnergy();
		else if (nt.equals(Type.CARBOHYDRATES))
			return nut.getCarbohydrates();
		else if (nt.equals(Type.FIBER))
			return nut.getFiber();
		else if(nt.equals(Type.SUGAR))
			return nut.getSugar();
		else
			return nut.getCholesterol();
	}
	public static String tamilToEnglish(String name){
		switch (name){
			case "\u0baa\u0bc1\u0bb0\u0ba4":
				return "protein";
			case "\u0b95\u0bca\u0bb4\u0bc1\u0baa\u0bcd\u0baa\u0bc1":
				return "cholesterol";
			case "\u0b9a\u0bb0\u0bcd\u0b95\u0bcd\u0b95\u0bb0\u0bc8":
				return "sugar";
			case "\u0b95\u0bbe\u0bb0\u0bcd\u0baa\u0bcb\u0bb9\u0bc8\u0b9f\u0bcd\u0bb0\u0bc7\u0b9f\u0bcd\u0b9f\u0bc1\u0b95\u0bb3\u0bcd":
				return "fiber"	;
			case "\u0b86\u0bb1\u0bcd\u0bb1\u0bb2\u0bcd":
				return "energy";
			default:
				return name;
		}
	}

	public boolean isMoreOptimal(NutrientType.Type type, Nutrients n1,Nutrients n2){
		if (type == Type.SUGAR || type==Type.CHOLESTEROL){
			return amountFromType(n1,type) <= 1.1*amountFromType(n1,type);
		} else {
			return amountFromType(n1,type)>=0.9*amountFromType(n1,type);
		}
	}

	public static Type nameToType(String name){
		switch(name){
			case "protein":
				return Type.PROTEIN;
			case "energy":
				return Type.ENERGY;
			case "carbohydrates":
				return Type.CARBOHYDRATES;
			case "fiber":
				return Type.FIBER;
			case "sugar":
				return Type.SUGAR;
			case "cholesterol":
				return Type.CHOLESTEROL;

		}
		return null;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public String getUnit_name() {
		return unit_name;
	}

	public void setUnit_name(String unit_name) {
		this.unit_name = unit_name;
	}

	public static Type[] getTypes() {
		return types;
	}

	public static String[] getIds() {
		return ids;
	}

	public static String[] getNames() {
		return names;
	}

	public static String[] getUnit_names() {
		return unit_names;
	}
}
