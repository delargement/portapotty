package Model;

import Model.Food;

import java.io.CharArrayReader;
import java.util.ArrayList;
import java.util.Objects;

public class FoodSet extends Food {
	private ArrayList<FoodItem> ingredients;

	public FoodSet(String name, Nutrients nutrients, ArrayList<FoodItem> ingredients){
		super(name,nutrients);
		this.ingredients=ingredients;

	}
	public FoodSet(String name,ArrayList<FoodItem> ingredients) {
		this(name,FoodItem.calcNutrients(ingredients),ingredients);
	}

	public FoodSet(String name) {
		this(name,new ArrayList<FoodItem>());
	}

	public static Nutrients calcNutrients(ArrayList<FoodSet> foodSets)	{
		Nutrients nt = new Nutrients();
		for (var v: foodSets){
			nt.addNutrients(FoodItem.calcNutrients(v.getIngredients()));
		}
		return nt;
	}


	public ArrayList<FoodItem> getIngredients() {
		return ingredients;
	}

	public void setIngredients(ArrayList<FoodItem> ingredients) {
		this.ingredients = ingredients;
	}

	public String printIngredients(){
		String s = "";
		boolean once=false;
		for(FoodItem v: ingredients) {
			if (once)
				s+=",";
			s += v.getName();
			once = true;
		}
		return s;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		if (!super.equals(o)) return false;
		FoodSet foodSet = (FoodSet) o;
		return getName().equals(foodSet.getName());
	}

	@Override
	public String toString() {
		return getName()+","+printIngredients();
	}
}
