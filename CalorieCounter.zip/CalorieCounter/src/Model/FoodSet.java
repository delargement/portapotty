package Model;

import Model.Food;

import java.io.CharArrayReader;
import java.util.ArrayList;

public class FoodSet extends Food {
	private ArrayList<FoodItem> ingredients;

	public FoodSet(String name, Nutrients nutrients, ArrayList<FoodItem> ingredients){
		super(name,nutrients);
		this.ingredients=ingredients;

	}
	public FoodSet(String name,ArrayList<FoodItem> ingredients) {
		this(name,calcNutrients(ingredients),ingredients);
	}

	public FoodSet(String name) {
		this(name,new ArrayList<FoodItem>());
	}

	public static Nutrients calcNutrients(ArrayList<FoodItem> ingredients){
		Nutrients nt = new Nutrients();
		for(var v: ingredients){
			nt.addNutrients(v.getNutrients());
		}
		return nt;
	}

	public ArrayList<FoodItem> getIngredients() {
		return ingredients;
	}

	public void setIngredients(ArrayList<FoodItem> ingredients) {
		this.ingredients = ingredients;
	}

	public String printIngredients(){
		String s = "";
		boolean once=false;
		for(FoodItem v: ingredients) {
			if (once)
				s+=",";
			s += v.getId();
			once = true;
		}
		return s;
	}

	@Override
	public String toString() {
		return getName()+","+printIngredients();
	}
}
