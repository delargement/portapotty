package Model;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;
import java.util.TreeSet;

public class Meal implements Comparable<Meal> {
	private LocalDateTime dateTime;
	private ArrayList<FoodSet> foodSets;

	public Meal(LocalDateTime dateTime, ArrayList<FoodSet> foodSets){
		this.dateTime = dateTime;
		this.foodSets = foodSets;
	}

	public int compareTo(Meal meal){
		return 	dateTime.compareTo(meal.getDateTime());
	}

	public LocalDateTime getDateTime() {
		return dateTime;
	}

	public String getFormattedDateTime(){
		return dateTime.toString();
	}
	public String getFormattedFoodSets(){
		String s = "";
		for(int i = 0; i < foodSets.size();++i) {
			if (i!=0)
				s+=",";
			s += foodSets.get(i).getName();
		}
		return s;
	}

	public void setDateTime(LocalDateTime dateTime) {
		this.dateTime = dateTime;
	}

	public ArrayList<FoodSet> getFoodSets() {
		return foodSets;
	}

	public void setFoodSets(ArrayList<FoodSet> foodSets) {
		this.foodSets = foodSets;
	}

	public String toString(){
		String s="";
		s += dateTime.toString() + ",";
		boolean once = false;
		for (var v: foodSets){
			if (once)
				s+=",";
			s += foodSets.toString() + ",";
			once = true;
		}
		return s;
	}
}
