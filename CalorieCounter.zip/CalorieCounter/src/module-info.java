module CalorieCounter {
	requires javafx.controls;
	requires javafx.fxml;

	opens Controller;
	opens View;
	opens Model;
}