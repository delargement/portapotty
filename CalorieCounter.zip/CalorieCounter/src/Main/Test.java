package Main;

import Model.FoodSet;
import Model.Meal;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;

public class Test {
	public static void main(String[] args){
//		ArrayList<Meal> meals = new ArrayList<>();
//		meals.add(new Meal(LocalDateTime.MAX,new ArrayList<FoodSet>()));
//		meals.add(new Meal(LocalDateTime.MIN,new ArrayList<FoodSet>()));
//		Collections.sort(meals);
//		System.out.println(meals);
	}
}
