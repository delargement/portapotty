package View;

import Model.MealData;
import javafx.animation.*;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;

import static java.lang.Math.cos;
import static java.lang.Math.sin;

public class Splash extends Application {
	private ImageView img;
	private double SPLASH_HEIGHT=200,SPLASH_WIDTH=500;

	public void rollingAnimation(Node node){
		Path path = new Path();
		path.getElements().add(new MoveTo(0,SPLASH_HEIGHT-100));
		path.getElements().add(new LineTo(SPLASH_WIDTH*2,SPLASH_HEIGHT-100));
		ParallelTransition parallelTransition = new ParallelTransition();
		PathTransition pathTransition = new PathTransition();
		pathTransition.setDuration(Duration.seconds(3));
		pathTransition.setPath(path);
		pathTransition.setNode(node);
		pathTransition.setCycleCount(Timeline.INDEFINITE);

		RotateTransition rotateTransition = new RotateTransition(Duration.millis(2000),node);
		rotateTransition.setByAngle(360f);
		rotateTransition.setCycleCount(Timeline.INDEFINITE);
		rotateTransition.setInterpolator(Interpolator.LINEAR);

		parallelTransition.getChildren().addAll(pathTransition,rotateTransition);
		parallelTransition.play();
	}

	public Path getCheeseWheel(double x,double y,double r){
		Path path = new Path();
		path.setFill(Color.YELLOW);
		path.setStroke(Color.BLACK);
		MoveTo moveTo = new MoveTo(x,y);

		ArcTo arc1 = new ArcTo();
		arc1.setRadiusX(r);
		arc1.setRadiusY(r);
		arc1.setX(x+2*r);
		arc1.setY(y);

		ArcTo arc2 =new ArcTo();
		arc2.setRadiusX(r);
		arc2.setRadiusY(r);
		arc2.setX(x+r);
		arc2.setY(y-r);

		LineTo line1 = new LineTo(x+r-5,y);
		LineTo line2 = new LineTo(x,y);

		path.getElements().addAll(moveTo,arc1,arc2,line1,line2);
		return path;
	}
	@Override
	public void start(Stage primaryStage) throws Exception {
		img = new ImageView(new Image("file:DataFiles/cheese.png"));
		VBox vbox =new VBox();
		Path p = getCheeseWheel(SPLASH_WIDTH/2,SPLASH_HEIGHT/2,75);
		rollingAnimation(p);
		ProgressBar progressBar = new ProgressBar();
		progressBar.setPrefWidth(SPLASH_WIDTH);
		vbox.getChildren().addAll(p,progressBar);
		new Thread(new Runnable() {
			@Override
			public void run() {
				for(int i =0; i <= 10; ++i){
					int n = i;
					Platform.runLater(new Runnable() {
						@Override
						public void run() {
							progressBar.setProgress(n*0.1);
						}
					});
					try {
						Thread.sleep(400);
					} catch (InterruptedException ex){
					}
				}
				Platform.runLater(new Runnable() {
					@Override
					public void run() {
						((Stage) progressBar.getScene().getWindow()).close();
						try {
							Parent root = FXMLLoader.load(getClass().getResource("application.fxml"));
							primaryStage.setTitle("Calorie Counter");
							primaryStage.getIcons().add(new Image("file:src/DataFiles/cheese.png"));
							primaryStage.setScene(new Scene(root, 1018, 654));
							primaryStage.show();
						}catch (IOException ex){
							ex.printStackTrace();
						}
					}
				});
			}

		}).start();
		Scene scene = new Scene(vbox,SPLASH_WIDTH,SPLASH_HEIGHT);
		primaryStage.setTitle("splash");
		primaryStage.getIcons().add(new Image("file:src/DataFiles/cheese.png"));
		primaryStage.setScene(scene);
		primaryStage.show();
	}
}
