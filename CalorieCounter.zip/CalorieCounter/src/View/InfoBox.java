package View;

import Controller.ApplicationController;
import Model.*;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;

import java.time.LocalDateTime;
import java.util.*;

import static java.lang.Integer.max;
import static java.time.temporal.ChronoUnit.DAYS;

public class InfoBox extends AnchorPane {
	enum InfoType{STREAK,AVERAGE,DISCOVERY}
	private static NutrientType.Type[] nutrientTypes = NutrientType.getTypes();
	private InfoType                            type;
	private NutrientType nutrientType;
	private final int                           WIDTH         =200,HEIGHT =200;
	private Rectangle rect;

	public InfoBox(InfoType type,NutrientType nutrientType){
		this();
		this.type = type;
		this.nutrientType = nutrientType;
	}
	public InfoBox(){
		setWidth(WIDTH);
		setHeight(HEIGHT);

		rect = new Rectangle(WIDTH,HEIGHT);
		rect.setFill(FoodBox.randomColor());
		rect.setStroke(Color.BLACK);
		rect.setStrokeWidth(5);
		getChildren().add(rect);
	}
	public int fillInfoBox(){
		ResourceBundle rb = ApplicationController.getRb();
		if (MealData.getMeals().size()==0)
			MealData.setMeals(MealData.readMeals());
		if (MealData.getMeals().isEmpty()) {
//			System.out.println("here");
			return -1;
		}
		Collections.sort(MealData.getMeals());
		ArrayList<Meal> meals = MealData.getMeals();
		if (type==InfoType.AVERAGE){
			int n = new Random().nextInt((int) Math.abs(DAYS.between(meals.get(0).getDateTime(), LocalDateTime.now()))+1);
			n = max(n,1);
			double amt=0;
			for(int i = meals.size()-1;i>=meals.size()-1-n;--i){
				if (meals.get(i).getDateTime().isBefore(LocalDateTime.now().minusDays(n)))
					break;
				for(var v: meals.get(i).getFoodSets()){
					amt += NutrientType.amountFromType(v.getNutrients(),nutrientType.getType());
				}
			}
			amt/=n;
			Label top = new Label(rb.getString("your average ") + " " + rb.getString(nutrientType.getType().name().toLowerCase()) + " " +
					rb.getString(" intake in the past ") + n + " " +
					rb.getString(" days is"));
			Label bottom = new Label(String.format("%.2f",amt)+ " " + nutrientType.getUnit_name());
			this.getChildren().addAll(top,bottom);

			top.setWrapText(true);
			top.setMaxSize(WIDTH-20,HEIGHT-20);
			top.relocate(20,20);

			bottom.setWrapText(true);
			bottom.relocate(WIDTH/4,HEIGHT/2);

			top.setFont(Font.font("Helvetica",14));
			bottom.setFont(Font.font("Helvetica",18));

		} else if (type==InfoType.STREAK){
			if (meals.isEmpty())
				return -1;
			Meal meal = meals.get(meals.size()-1);
			double model = NutrientType.amountFromType(FoodSet.calcNutrients(meal.getFoodSets()),nutrientType.getType());
			ArrayList<Meal> pastMeals= new ArrayList<>();
			pastMeals.add(meal);
			int i = meals.size()-2;
			while(i>0) {
				double prev = NutrientType.amountFromType(FoodSet.calcNutrients(meals.get(i).getFoodSets()),nutrientType.getType());
				if (nutrientType.getType() == NutrientType.Type.SUGAR || nutrientType.getType() == NutrientType.Type.CHOLESTEROL){
					if (prev <= 1.1*model){
						pastMeals.add(meals.get(i));
					} else
						break;
				} else{
					if (prev>=0.9*model){
						pastMeals.add(meals.get(i));
					} else
						break;
				}
				--i;
			}
			UserInfo userInfo = new UserInfo();
			userInfo.updateFromFile();
			Label top = new Label(rb.getString("You've maintained an adherence of"));
			double opt = NutrientType.getOptimal(nutrientType.getType(),userInfo);
//			System.out.println(opt + " " + model);
			double amt = model/opt;
			if (amt > 100)
				amt = (model-opt)/opt;
			if (amt >100)
				return -1;
			Label mid = new Label(String.format("%.2f",amt)+"%");
			Label bot = new Label(rb.getString(" to the optimal/max amount of ") + rb.getString(nutrientType.getType().name().toLowerCase()));
			getChildren().addAll(top,mid,bot);

			top.setWrapText(true);
			mid.setWrapText(true);
			bot.setWrapText(true);

			top.setMaxSize(WIDTH-20,HEIGHT-20);
			top.relocate(20,20);
			mid.relocate(20,HEIGHT/2);
			bot.relocate(20,0.8*HEIGHT);

			bot.setMaxWidth(WIDTH-20);


			top.setFont(Font.font("Helvetica",14));
			mid.setFont(Font.font("Helvetica",40));


		} else if (type == InfoType.DISCOVERY){
			if (meals.isEmpty())return -1;
			Random random = new Random();
			int n=random.nextInt(meals.size());
			if (n==0){
				return fillInfoBox();
			}
			HashSet<FoodItem> fi = new HashSet<>();
			for(int i=meals.size()-1;i>=meals.size()-1-n;--i){
				for(var v: meals.get(i).getFoodSets()){
					fi.addAll(v.getIngredients());
				}
			}
			HashSet<FoodItem> bef = new HashSet<>();
			for(int i=0; i < meals.size()-1-n;++i){
				for(var v:meals.get(i).getFoodSets()){
					bef.addAll(v.getIngredients());
				}
			}
			fi.removeAll(bef);
			Label top = new Label(rb.getString("you discovered "));
			Label mid = new Label(fi.size()+"");
			Label bot = new Label(rb.getString(" new food items in the past ") + n + " " + rb.getString(" days"));
			getChildren().addAll(top,mid,bot);

			top.setWrapText(true);
			mid.setWrapText(true);
			bot.setWrapText(true);

			top.setMaxSize(WIDTH-30,HEIGHT-20);
			top.relocate(20,20);
			mid.relocate(WIDTH/2,HEIGHT/2);
			mid.setAlignment(Pos.CENTER);
			bot.relocate(20,0.8*HEIGHT);

			top.setFont(Font.font("Helvetica",14));
			mid.setFont(Font.font("Helvetica",40));
		}
		return 0;
	}
	public static InfoBox generateInfoBox(){
		InfoBox tmp = new InfoBox();
		tmp.randomiseInfoBox();
		return tmp;
	}
	public void randomiseInfoBox(){
		Random r = new Random();
		InfoType arr[] = {InfoType.STREAK,InfoType.AVERAGE,InfoType.DISCOVERY};
		setType(arr[r.nextInt(3)]);
		setNutrientType(new NutrientType(Arrays.asList(nutrientTypes).get(r.nextInt(nutrientTypes.length))));
	}

	public InfoType getType() {
		return type;
	}

	public void setType(InfoType type) {
		this.type = type;
	}

	public NutrientType getNutrientType() {
		return nutrientType;
	}

	public void setNutrientType(NutrientType nutrientType) {
		this.nutrientType = nutrientType;
	}

}
