package View;

import Model.Food;
import Model.FoodSet;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.util.Random;

public class FoodBox extends AnchorPane{
	private Food food;
	private final static double WIDTH =100,HEIGHT=100;
	private Rectangle rect;
	private Button delete,select;
	private Label name;
	private Color color;
	private static final Color[] possibleColors = {Color.IVORY,Color.GOLD,Color.AQUA,Color.INDIANRED,Color.LAVENDER};

	public FoodBox(double width, double height, Color color, Food food){
		super();
		this.food = food;
		super.setWidth(width);
		super.setHeight(height);
		this.color=color;

		rect = new Rectangle(width,height);
		rect.setFill(color);
		name = new Label(food.getName());
		delete = new Button("X");

		super.getChildren().addAll(rect,delete,name);
		name.relocate(0,0);
		name.setMaxSize(WIDTH,0.8*HEIGHT);
		name.setWrapText(true);
		delete.relocate(0.2*width,0.8*height);
	}
	public void giveSelectButton(){
		select=new Button("+");
		getChildren().add(select);
		select.relocate(4.0/5*getWidth(),4.0/5*getHeight());
	}

	public static Color randomColor(){
		return possibleColors[new Random().nextInt(possibleColors.length)];
	}

	public FoodBox(Color color, Food food){
		this(WIDTH,HEIGHT,color,food);
	}

	public FoodBox(Food food){
		this(randomColor(),food);
	}

	public Food getFood() {
		return food;
	}

	public void setFood(Food food) {
		this.food= food;
	}

	public void setColor(Color color){
		rect.setFill(color);
	}

	public Rectangle getRect() {
		return rect;
	}

	public void setRect(Rectangle rect) {
		this.rect = rect;
	}

	public Button getDelete() {
		return delete;
	}

	public void setDelete(Button delete) {
		this.delete = delete;
	}

	public Label getName() {
		return name;
	}

	public void setName(Label name) {
		this.name = name;
	}

	public Button getSelect() {
		return select;
	}

	public void setSelect(Button select) {
		this.select = select;
	}

	public Color getColor() {
		return color;
	}
}
