package View;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class AddPresetMenu extends Application {

	public void start(Stage menu) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource("AddPreset.fxml"));
		menu.setTitle("Add Preset");
		menu.setScene(new Scene(root, 870, 540));
		menu.showAndWait();
	}
}
